﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASFuelControl.Common.Enumerators
{
    public enum NozzleStateEnum
    {
        Normal = 0,
        LiterCheck = 1,
        Locked = 2,
        InvoicePrint,
        LiterCheckPrint
    }
}
