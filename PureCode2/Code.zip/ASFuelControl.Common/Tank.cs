﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASFuelControl.Common
{
    public class Tank
    {
        public int Channel { set; get; }
        public int Address { set; get; }
        public int AtgProbeProtocol { set; get; }
    }
}
