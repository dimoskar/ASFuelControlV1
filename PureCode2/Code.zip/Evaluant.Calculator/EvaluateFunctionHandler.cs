﻿namespace NCalc
{
    public delegate void EvaluateFunctionHandler(string name, FunctionArgs args);
}
