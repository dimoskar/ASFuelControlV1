﻿namespace BalanceExporter.Reports
{
    
    
    public partial class BalanceDS {
        partial class BalanceDataTable
        {
        }
    }
}
