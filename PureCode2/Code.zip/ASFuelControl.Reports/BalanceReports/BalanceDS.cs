﻿namespace ASFuelControl.Reports.BalanceReports {
    
    
    public partial class BalanceDS {
        partial class BalanceDataTable
        {
        }
    }
}
