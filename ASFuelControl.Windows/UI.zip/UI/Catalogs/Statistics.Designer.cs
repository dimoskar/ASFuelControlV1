﻿namespace ASFuelControl.Windows.UI.Catalogs
{
    partial class Statistics
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Telerik.WinControls.UI.GridViewDateTimeColumn gridViewDateTimeColumn3 = new Telerik.WinControls.UI.GridViewDateTimeColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn19 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn20 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn21 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn22 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn10 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn11 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn23 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn24 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.Data.GroupDescriptor groupDescriptor10 = new Telerik.WinControls.Data.GroupDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor11 = new Telerik.WinControls.Data.SortDescriptor();
            Telerik.WinControls.Data.GroupDescriptor groupDescriptor11 = new Telerik.WinControls.Data.GroupDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor12 = new Telerik.WinControls.Data.SortDescriptor();
            Telerik.WinControls.Data.GroupDescriptor groupDescriptor12 = new Telerik.WinControls.Data.GroupDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor13 = new Telerik.WinControls.Data.SortDescriptor();
            Telerik.WinControls.Data.GroupDescriptor groupDescriptor13 = new Telerik.WinControls.Data.GroupDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor14 = new Telerik.WinControls.Data.SortDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor15 = new Telerik.WinControls.Data.SortDescriptor();
            Telerik.WinControls.UI.GridViewSummaryItem gridViewSummaryItem4 = new Telerik.WinControls.UI.GridViewSummaryItem();
            Telerik.WinControls.UI.GridViewSummaryItem gridViewSummaryItem5 = new Telerik.WinControls.UI.GridViewSummaryItem();
            Telerik.WinControls.UI.GridViewSummaryItem gridViewSummaryItem6 = new Telerik.WinControls.UI.GridViewSummaryItem();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn25 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn26 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn27 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn28 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn29 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn30 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn31 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn12 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn13 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn32 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn14 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.Data.GroupDescriptor groupDescriptor14 = new Telerik.WinControls.Data.GroupDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor16 = new Telerik.WinControls.Data.SortDescriptor();
            Telerik.WinControls.Data.GroupDescriptor groupDescriptor15 = new Telerik.WinControls.Data.GroupDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor17 = new Telerik.WinControls.Data.SortDescriptor();
            Telerik.WinControls.Data.GroupDescriptor groupDescriptor16 = new Telerik.WinControls.Data.GroupDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor18 = new Telerik.WinControls.Data.SortDescriptor();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn15 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn16 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewDateTimeColumn gridViewDateTimeColumn4 = new Telerik.WinControls.UI.GridViewDateTimeColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn33 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn34 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn35 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn36 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn17 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn18 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.Data.GroupDescriptor groupDescriptor17 = new Telerik.WinControls.Data.GroupDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor19 = new Telerik.WinControls.Data.SortDescriptor();
            Telerik.WinControls.Data.GroupDescriptor groupDescriptor18 = new Telerik.WinControls.Data.GroupDescriptor();
            Telerik.WinControls.Data.SortDescriptor sortDescriptor20 = new Telerik.WinControls.Data.SortDescriptor();
            this.radPageView1 = new Telerik.WinControls.UI.RadPageView();
            this.radPageViewPage1 = new Telerik.WinControls.UI.RadPageViewPage();
            this.salesViewRadGridView = new Telerik.WinControls.UI.RadGridView();
            this.salesViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.salesDateTo = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.salesDateFrom = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radPageViewPage2 = new Telerik.WinControls.UI.RadPageViewPage();
            this.tankFillingViewRadGridView = new Telerik.WinControls.UI.RadGridView();
            this.tankFillingViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.radButton3 = new Telerik.WinControls.UI.RadButton();
            this.radButton4 = new Telerik.WinControls.UI.RadButton();
            this.fillingsTo = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.fillingsFrom = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.radPageViewPage3 = new Telerik.WinControls.UI.RadPageViewPage();
            this.invoiceRadGridView = new Telerik.WinControls.UI.RadGridView();
            this.invoiceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.radButton5 = new Telerik.WinControls.UI.RadButton();
            this.radButton6 = new Telerik.WinControls.UI.RadButton();
            this.invoiceDateTo = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.invoiceDateFrom = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).BeginInit();
            this.radPageView1.SuspendLayout();
            this.radPageViewPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salesViewRadGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesViewRadGridView.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesViewBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesDateTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesDateFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            this.radPageViewPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingViewRadGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingViewRadGridView.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingViewBindingSource)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fillingsTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fillingsFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            this.radPageViewPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceRadGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceRadGridView.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceDateTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceDateFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            this.SuspendLayout();
            // 
            // radPageView1
            // 
            this.radPageView1.Controls.Add(this.radPageViewPage1);
            this.radPageView1.Controls.Add(this.radPageViewPage2);
            this.radPageView1.Controls.Add(this.radPageViewPage3);
            this.radPageView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radPageView1.Location = new System.Drawing.Point(0, 0);
            this.radPageView1.Name = "radPageView1";
            this.radPageView1.SelectedPage = this.radPageViewPage1;
            this.radPageView1.Size = new System.Drawing.Size(1004, 613);
            this.radPageView1.TabIndex = 0;
            this.radPageView1.Text = "radPageView1";
            ((Telerik.WinControls.UI.RadPageViewStripElement)(this.radPageView1.GetChildAt(0))).StripButtons = Telerik.WinControls.UI.StripViewButtons.None;
            // 
            // radPageViewPage1
            // 
            this.radPageViewPage1.Controls.Add(this.salesViewRadGridView);
            this.radPageViewPage1.Controls.Add(this.panel1);
            this.radPageViewPage1.Location = new System.Drawing.Point(10, 37);
            this.radPageViewPage1.Name = "radPageViewPage1";
            this.radPageViewPage1.Size = new System.Drawing.Size(983, 565);
            this.radPageViewPage1.Text = "Ταμείο Ημέρας";
            // 
            // salesViewRadGridView
            // 
            this.salesViewRadGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.salesViewRadGridView.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.salesViewRadGridView.GroupExpandAnimationType = Telerik.WinControls.UI.GridExpandAnimationType.GradientWipe;
            this.salesViewRadGridView.Location = new System.Drawing.Point(0, 51);
            // 
            // salesViewRadGridView
            // 
            this.salesViewRadGridView.MasterTemplate.AllowAddNewRow = false;
            this.salesViewRadGridView.MasterTemplate.AllowDeleteRow = false;
            this.salesViewRadGridView.MasterTemplate.AllowDragToGroup = false;
            this.salesViewRadGridView.MasterTemplate.AutoGenerateColumns = false;
            gridViewDateTimeColumn3.FieldName = "TransactionTimeStamp";
            gridViewDateTimeColumn3.FormatString = "{0:dd/MM/yyyy HH:mm}";
            gridViewDateTimeColumn3.HeaderText = "Ημερομηνία";
            gridViewDateTimeColumn3.IsAutoGenerated = true;
            gridViewDateTimeColumn3.Name = "TransactionTimeStamp";
            gridViewDateTimeColumn3.SortOrder = Telerik.WinControls.UI.RadSortOrder.Ascending;
            gridViewDateTimeColumn3.Width = 120;
            gridViewDecimalColumn19.FieldName = "Volume";
            gridViewDecimalColumn19.HeaderText = "Όγκος";
            gridViewDecimalColumn19.IsAutoGenerated = true;
            gridViewDecimalColumn19.Name = "Volume";
            gridViewDecimalColumn19.Width = 100;
            gridViewDecimalColumn20.FieldName = "VolumeNormalized";
            gridViewDecimalColumn20.HeaderText = "Όγκος 15οC";
            gridViewDecimalColumn20.IsAutoGenerated = true;
            gridViewDecimalColumn20.Name = "VolumeNormalized";
            gridViewDecimalColumn20.Width = 100;
            gridViewDecimalColumn21.FieldName = "UnitPrice";
            gridViewDecimalColumn21.HeaderText = "Τιμή Λίτρου";
            gridViewDecimalColumn21.IsAutoGenerated = true;
            gridViewDecimalColumn21.Name = "UnitPrice";
            gridViewDecimalColumn21.Width = 100;
            gridViewDecimalColumn22.FieldName = "TotalPrice";
            gridViewDecimalColumn22.HeaderText = "Σύνολο";
            gridViewDecimalColumn22.IsAutoGenerated = true;
            gridViewDecimalColumn22.Name = "TotalPrice";
            gridViewDecimalColumn22.Width = 100;
            gridViewTextBoxColumn10.FieldName = "UserName";
            gridViewTextBoxColumn10.HeaderText = "Χρήστης";
            gridViewTextBoxColumn10.IsAutoGenerated = true;
            gridViewTextBoxColumn10.Name = "UserName";
            gridViewTextBoxColumn10.Width = 100;
            gridViewTextBoxColumn11.FieldName = "Name";
            gridViewTextBoxColumn11.HeaderText = "Είδος Καύσιμου";
            gridViewTextBoxColumn11.IsAutoGenerated = true;
            gridViewTextBoxColumn11.Name = "Name";
            gridViewTextBoxColumn11.Width = 100;
            gridViewDecimalColumn23.DataType = typeof(int);
            gridViewDecimalColumn23.FieldName = "OfficialPumpNumber";
            gridViewDecimalColumn23.HeaderText = "Αντλία";
            gridViewDecimalColumn23.IsAutoGenerated = true;
            gridViewDecimalColumn23.Name = "OfficialPumpNumber";
            gridViewDecimalColumn23.Width = 100;
            gridViewDecimalColumn24.DataType = typeof(int);
            gridViewDecimalColumn24.FieldName = "OfficialNozzleNumber";
            gridViewDecimalColumn24.HeaderText = "Ακροσωλήνιο";
            gridViewDecimalColumn24.IsAutoGenerated = true;
            gridViewDecimalColumn24.Name = "OfficialNozzleNumber";
            gridViewDecimalColumn24.Width = 100;
            this.salesViewRadGridView.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewDateTimeColumn3,
            gridViewDecimalColumn19,
            gridViewDecimalColumn20,
            gridViewDecimalColumn21,
            gridViewDecimalColumn22,
            gridViewTextBoxColumn10,
            gridViewTextBoxColumn11,
            gridViewDecimalColumn23,
            gridViewDecimalColumn24});
            this.salesViewRadGridView.MasterTemplate.DataSource = this.salesViewBindingSource;
            sortDescriptor11.PropertyName = "UserName";
            groupDescriptor10.GroupNames.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor11});
            sortDescriptor12.PropertyName = "Name";
            groupDescriptor11.GroupNames.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor12});
            sortDescriptor13.PropertyName = "OfficialPumpNumber";
            groupDescriptor12.GroupNames.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor13});
            sortDescriptor14.PropertyName = "OfficialNozzleNumber";
            groupDescriptor13.GroupNames.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor14});
            this.salesViewRadGridView.MasterTemplate.GroupDescriptors.AddRange(new Telerik.WinControls.Data.GroupDescriptor[] {
            groupDescriptor10,
            groupDescriptor11,
            groupDescriptor12,
            groupDescriptor13});
            sortDescriptor15.PropertyName = "TransactionTimeStamp";
            this.salesViewRadGridView.MasterTemplate.SortDescriptors.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor15});
            gridViewSummaryItem4.Aggregate = Telerik.WinControls.UI.GridAggregateFunction.Sum;
            gridViewSummaryItem4.FormatString = "{0:N2}";
            gridViewSummaryItem4.Name = "Volume";
            gridViewSummaryItem5.Aggregate = Telerik.WinControls.UI.GridAggregateFunction.Sum;
            gridViewSummaryItem5.FormatString = "{0:N2}";
            gridViewSummaryItem5.Name = "VolumeNormalized";
            gridViewSummaryItem6.Aggregate = Telerik.WinControls.UI.GridAggregateFunction.Sum;
            gridViewSummaryItem6.FormatString = "{0:N2}";
            gridViewSummaryItem6.Name = "TotalPrice";
            this.salesViewRadGridView.MasterTemplate.SummaryRowsBottom.Add(new Telerik.WinControls.UI.GridViewSummaryRowItem(new Telerik.WinControls.UI.GridViewSummaryItem[] {
                gridViewSummaryItem4,
                gridViewSummaryItem5,
                gridViewSummaryItem6}));
            this.salesViewRadGridView.Name = "salesViewRadGridView";
            this.salesViewRadGridView.ReadOnly = true;
            this.salesViewRadGridView.ShowGroupPanel = false;
            this.salesViewRadGridView.Size = new System.Drawing.Size(983, 514);
            this.salesViewRadGridView.TabIndex = 1;
            this.salesViewRadGridView.Text = "radGridView1";
            // 
            // salesViewBindingSource
            // 
            this.salesViewBindingSource.DataSource = typeof(ASFuelControl.Data.SalesView);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radButton2);
            this.panel1.Controls.Add(this.radButton1);
            this.panel1.Controls.Add(this.salesDateTo);
            this.panel1.Controls.Add(this.radLabel2);
            this.panel1.Controls.Add(this.salesDateFrom);
            this.panel1.Controls.Add(this.radLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(10);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(7);
            this.panel1.Size = new System.Drawing.Size(983, 51);
            this.panel1.TabIndex = 0;
            // 
            // radButton2
            // 
            this.radButton2.Dock = System.Windows.Forms.DockStyle.Right;
            this.radButton2.Image = global::ASFuelControl.Windows.Properties.Resources.Search;
            this.radButton2.Location = new System.Drawing.Point(938, 7);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(38, 37);
            this.radButton2.TabIndex = 5;
            this.radButton2.Click += new System.EventHandler(this.radButton2_Click);
            // 
            // radButton1
            // 
            this.radButton1.Dock = System.Windows.Forms.DockStyle.Left;
            this.radButton1.Image = global::ASFuelControl.Windows.Properties.Resources.Search;
            this.radButton1.Location = new System.Drawing.Point(446, 7);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(38, 37);
            this.radButton1.TabIndex = 4;
            this.radButton1.Click += new System.EventHandler(this.radButton1_Click);
            // 
            // salesDateTo
            // 
            this.salesDateTo.AutoSize = false;
            this.salesDateTo.Dock = System.Windows.Forms.DockStyle.Left;
            this.salesDateTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.salesDateTo.Location = new System.Drawing.Point(274, 7);
            this.salesDateTo.Name = "salesDateTo";
            this.salesDateTo.Size = new System.Drawing.Size(172, 37);
            this.salesDateTo.TabIndex = 3;
            this.salesDateTo.TabStop = false;
            this.salesDateTo.Text = "Σάββατο, 7 Ιουνίου 2014";
            this.salesDateTo.Value = new System.DateTime(2014, 6, 7, 10, 52, 7, 271);
            // 
            // radLabel2
            // 
            this.radLabel2.AutoSize = false;
            this.radLabel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.radLabel2.Location = new System.Drawing.Point(228, 7);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.radLabel2.Size = new System.Drawing.Size(46, 37);
            this.radLabel2.TabIndex = 2;
            this.radLabel2.Text = "Εώς";
            this.radLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // salesDateFrom
            // 
            this.salesDateFrom.AutoSize = false;
            this.salesDateFrom.Dock = System.Windows.Forms.DockStyle.Left;
            this.salesDateFrom.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.salesDateFrom.Location = new System.Drawing.Point(53, 7);
            this.salesDateFrom.Name = "salesDateFrom";
            this.salesDateFrom.Size = new System.Drawing.Size(175, 37);
            this.salesDateFrom.TabIndex = 1;
            this.salesDateFrom.TabStop = false;
            this.salesDateFrom.Text = "Σάββατο, 7 Ιουνίου 2014";
            this.salesDateFrom.Value = new System.DateTime(2014, 6, 7, 10, 52, 7, 271);
            // 
            // radLabel1
            // 
            this.radLabel1.AutoSize = false;
            this.radLabel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.radLabel1.Location = new System.Drawing.Point(7, 7);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(46, 37);
            this.radLabel1.TabIndex = 0;
            this.radLabel1.Text = "Από";
            this.radLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // radPageViewPage2
            // 
            this.radPageViewPage2.Controls.Add(this.tankFillingViewRadGridView);
            this.radPageViewPage2.Controls.Add(this.panel2);
            this.radPageViewPage2.Location = new System.Drawing.Point(10, 37);
            this.radPageViewPage2.Name = "radPageViewPage2";
            this.radPageViewPage2.Size = new System.Drawing.Size(983, 565);
            this.radPageViewPage2.Text = "Παραλαβές / Εξαγωγές";
            // 
            // tankFillingViewRadGridView
            // 
            this.tankFillingViewRadGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tankFillingViewRadGridView.Location = new System.Drawing.Point(0, 51);
            // 
            // 
            // 
            this.tankFillingViewRadGridView.MasterTemplate.AllowAddNewRow = false;
            this.tankFillingViewRadGridView.MasterTemplate.AllowDeleteRow = false;
            this.tankFillingViewRadGridView.MasterTemplate.AutoGenerateColumns = false;
            gridViewDecimalColumn25.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn25.FieldName = "INVVolume";
            gridViewDecimalColumn25.HeaderText = "Όγκος";
            gridViewDecimalColumn25.IsAutoGenerated = true;
            gridViewDecimalColumn25.Name = "INVVolume";
            gridViewDecimalColumn25.Width = 100;
            gridViewDecimalColumn26.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn26.FieldName = "INVVolumeNormalized";
            gridViewDecimalColumn26.HeaderText = "Όγκος 15οC";
            gridViewDecimalColumn26.IsAutoGenerated = true;
            gridViewDecimalColumn26.Name = "INVVolumeNormalized";
            gridViewDecimalColumn26.Width = 100;
            gridViewDecimalColumn27.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn27.FieldName = "TFVolume";
            gridViewDecimalColumn27.HeaderText = "Πραγμ. Όγκος";
            gridViewDecimalColumn27.IsAutoGenerated = true;
            gridViewDecimalColumn27.Name = "TFVolume";
            gridViewDecimalColumn27.Width = 100;
            gridViewDecimalColumn28.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn28.FieldName = "TFVolumeNormalized";
            gridViewDecimalColumn28.HeaderText = "Πραγμ. Όγκος 15οC";
            gridViewDecimalColumn28.IsAutoGenerated = true;
            gridViewDecimalColumn28.Name = "TFVolumeNormalized";
            gridViewDecimalColumn28.Width = 100;
            gridViewDecimalColumn29.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn29.FieldName = "LevelStart";
            gridViewDecimalColumn29.HeaderText = "Στάθμη Εναρξ.";
            gridViewDecimalColumn29.IsAutoGenerated = true;
            gridViewDecimalColumn29.Name = "LevelStart";
            gridViewDecimalColumn29.Width = 100;
            gridViewDecimalColumn30.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn30.FieldName = "LevelEnd";
            gridViewDecimalColumn30.HeaderText = "Στάθμη Λήξης";
            gridViewDecimalColumn30.IsAutoGenerated = true;
            gridViewDecimalColumn30.Name = "LevelEnd";
            gridViewDecimalColumn30.Width = 100;
            gridViewDecimalColumn31.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn31.FieldName = "FuelDensity";
            gridViewDecimalColumn31.HeaderText = "Πυκνότητα";
            gridViewDecimalColumn31.IsAutoGenerated = true;
            gridViewDecimalColumn31.Name = "FuelDensity";
            gridViewDecimalColumn31.Width = 100;
            gridViewTextBoxColumn12.FieldName = "UserName";
            gridViewTextBoxColumn12.HeaderText = "Χρήστης";
            gridViewTextBoxColumn12.IsAutoGenerated = true;
            gridViewTextBoxColumn12.Name = "UserName";
            gridViewTextBoxColumn12.Width = 100;
            gridViewTextBoxColumn13.FieldName = "Name";
            gridViewTextBoxColumn13.HeaderText = "Είδος Καυσίμου";
            gridViewTextBoxColumn13.IsAutoGenerated = true;
            gridViewTextBoxColumn13.Name = "Name";
            gridViewTextBoxColumn13.Width = 100;
            gridViewDecimalColumn32.DataType = typeof(System.Nullable<int>);
            gridViewDecimalColumn32.FieldName = "TankNumber";
            gridViewDecimalColumn32.HeaderText = "Δεξαμενή";
            gridViewDecimalColumn32.IsAutoGenerated = true;
            gridViewDecimalColumn32.Name = "TankNumber";
            gridViewDecimalColumn32.Width = 100;
            gridViewTextBoxColumn14.FieldName = "Description";
            gridViewTextBoxColumn14.HeaderText = "Κίνηση";
            gridViewTextBoxColumn14.IsAutoGenerated = true;
            gridViewTextBoxColumn14.Name = "Description";
            gridViewTextBoxColumn14.Width = 100;
            this.tankFillingViewRadGridView.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewDecimalColumn25,
            gridViewDecimalColumn26,
            gridViewDecimalColumn27,
            gridViewDecimalColumn28,
            gridViewDecimalColumn29,
            gridViewDecimalColumn30,
            gridViewDecimalColumn31,
            gridViewTextBoxColumn12,
            gridViewTextBoxColumn13,
            gridViewDecimalColumn32,
            gridViewTextBoxColumn14});
            this.tankFillingViewRadGridView.MasterTemplate.DataSource = this.tankFillingViewBindingSource;
            sortDescriptor16.PropertyName = "Name";
            groupDescriptor14.GroupNames.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor16});
            sortDescriptor17.PropertyName = "TankNumber";
            groupDescriptor15.GroupNames.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor17});
            sortDescriptor18.PropertyName = "Description";
            groupDescriptor16.GroupNames.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor18});
            this.tankFillingViewRadGridView.MasterTemplate.GroupDescriptors.AddRange(new Telerik.WinControls.Data.GroupDescriptor[] {
            groupDescriptor14,
            groupDescriptor15,
            groupDescriptor16});
            this.tankFillingViewRadGridView.Name = "tankFillingViewRadGridView";
            this.tankFillingViewRadGridView.ReadOnly = true;
            this.tankFillingViewRadGridView.ShowGroupPanel = false;
            this.tankFillingViewRadGridView.Size = new System.Drawing.Size(983, 514);
            this.tankFillingViewRadGridView.TabIndex = 0;
            this.tankFillingViewRadGridView.Text = "radGridView1";
            // 
            // tankFillingViewBindingSource
            // 
            this.tankFillingViewBindingSource.DataSource = typeof(ASFuelControl.Data.TankFillingView);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radButton3);
            this.panel2.Controls.Add(this.radButton4);
            this.panel2.Controls.Add(this.fillingsTo);
            this.panel2.Controls.Add(this.radLabel3);
            this.panel2.Controls.Add(this.fillingsFrom);
            this.panel2.Controls.Add(this.radLabel4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(10);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(7);
            this.panel2.Size = new System.Drawing.Size(983, 51);
            this.panel2.TabIndex = 1;
            // 
            // radButton3
            // 
            this.radButton3.Dock = System.Windows.Forms.DockStyle.Right;
            this.radButton3.Image = global::ASFuelControl.Windows.Properties.Resources.Search;
            this.radButton3.Location = new System.Drawing.Point(938, 7);
            this.radButton3.Name = "radButton3";
            this.radButton3.Size = new System.Drawing.Size(38, 37);
            this.radButton3.TabIndex = 5;
            this.radButton3.Click += new System.EventHandler(this.radButton3_Click);
            // 
            // radButton4
            // 
            this.radButton4.Dock = System.Windows.Forms.DockStyle.Left;
            this.radButton4.Image = global::ASFuelControl.Windows.Properties.Resources.Search;
            this.radButton4.Location = new System.Drawing.Point(446, 7);
            this.radButton4.Name = "radButton4";
            this.radButton4.Size = new System.Drawing.Size(38, 37);
            this.radButton4.TabIndex = 4;
            this.radButton4.Click += new System.EventHandler(this.radButton4_Click);
            // 
            // fillingsTo
            // 
            this.fillingsTo.AutoSize = false;
            this.fillingsTo.Dock = System.Windows.Forms.DockStyle.Left;
            this.fillingsTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.fillingsTo.Location = new System.Drawing.Point(274, 7);
            this.fillingsTo.Name = "fillingsTo";
            this.fillingsTo.Size = new System.Drawing.Size(172, 37);
            this.fillingsTo.TabIndex = 3;
            this.fillingsTo.TabStop = false;
            this.fillingsTo.Text = "Σάββατο, 7 Ιουνίου 2014";
            this.fillingsTo.Value = new System.DateTime(2014, 6, 7, 10, 52, 7, 271);
            // 
            // radLabel3
            // 
            this.radLabel3.AutoSize = false;
            this.radLabel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.radLabel3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.radLabel3.Location = new System.Drawing.Point(228, 7);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.radLabel3.Size = new System.Drawing.Size(46, 37);
            this.radLabel3.TabIndex = 2;
            this.radLabel3.Text = "Εώς";
            this.radLabel3.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // fillingsFrom
            // 
            this.fillingsFrom.AutoSize = false;
            this.fillingsFrom.Dock = System.Windows.Forms.DockStyle.Left;
            this.fillingsFrom.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.fillingsFrom.Location = new System.Drawing.Point(53, 7);
            this.fillingsFrom.Name = "fillingsFrom";
            this.fillingsFrom.Size = new System.Drawing.Size(175, 37);
            this.fillingsFrom.TabIndex = 1;
            this.fillingsFrom.TabStop = false;
            this.fillingsFrom.Text = "Σάββατο, 7 Ιουνίου 2014";
            this.fillingsFrom.Value = new System.DateTime(2014, 6, 7, 10, 52, 7, 271);
            // 
            // radLabel4
            // 
            this.radLabel4.AutoSize = false;
            this.radLabel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.radLabel4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.radLabel4.Location = new System.Drawing.Point(7, 7);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(46, 37);
            this.radLabel4.TabIndex = 0;
            this.radLabel4.Text = "Από";
            this.radLabel4.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // radPageViewPage3
            // 
            this.radPageViewPage3.Controls.Add(this.invoiceRadGridView);
            this.radPageViewPage3.Controls.Add(this.panel3);
            this.radPageViewPage3.Location = new System.Drawing.Point(10, 37);
            this.radPageViewPage3.Name = "radPageViewPage3";
            this.radPageViewPage3.Size = new System.Drawing.Size(983, 565);
            this.radPageViewPage3.Text = "Παραστατικά";
            // 
            // invoiceRadGridView
            // 
            this.invoiceRadGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.invoiceRadGridView.Location = new System.Drawing.Point(0, 51);
            // 
            // invoiceRadGridView
            // 
            this.invoiceRadGridView.MasterTemplate.AllowAddNewRow = false;
            this.invoiceRadGridView.MasterTemplate.AllowDeleteRow = false;
            this.invoiceRadGridView.MasterTemplate.AutoGenerateColumns = false;
            gridViewTextBoxColumn15.FieldName = "Trader.Name";
            gridViewTextBoxColumn15.HeaderText = "Συναλλασσόμενος";
            gridViewTextBoxColumn15.IsAutoGenerated = true;
            gridViewTextBoxColumn15.Name = "Trader";
            gridViewTextBoxColumn15.Width = 200;
            gridViewTextBoxColumn16.FieldName = "Vehicle.PlateNumber";
            gridViewTextBoxColumn16.HeaderText = "Πινακίδες";
            gridViewTextBoxColumn16.IsAutoGenerated = true;
            gridViewTextBoxColumn16.Name = "Vehicle";
            gridViewTextBoxColumn16.Width = 100;
            gridViewDateTimeColumn4.FieldName = "TransactionDate";
            gridViewDateTimeColumn4.FormatInfo = new System.Globalization.CultureInfo("");
            gridViewDateTimeColumn4.FormatString = "{0:dd/MM/yyyy HH:mm}";
            gridViewDateTimeColumn4.HeaderText = "Ημερομηνία";
            gridViewDateTimeColumn4.IsAutoGenerated = true;
            gridViewDateTimeColumn4.Name = "TransactionDate";
            gridViewDateTimeColumn4.Width = 100;
            gridViewDecimalColumn33.DataType = typeof(int);
            gridViewDecimalColumn33.FieldName = "Number";
            gridViewDecimalColumn33.HeaderText = "Αριθμός";
            gridViewDecimalColumn33.IsAutoGenerated = true;
            gridViewDecimalColumn33.Name = "Number";
            gridViewDecimalColumn33.Width = 80;
            gridViewDecimalColumn34.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn34.FieldName = "NettoAmount";
            gridViewDecimalColumn34.HeaderText = "Ποσό";
            gridViewDecimalColumn34.IsAutoGenerated = true;
            gridViewDecimalColumn34.Name = "NettoAmount";
            gridViewDecimalColumn34.Width = 80;
            gridViewDecimalColumn35.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn35.FieldName = "VatAmount";
            gridViewDecimalColumn35.HeaderText = "Φ.Π.Α.";
            gridViewDecimalColumn35.IsAutoGenerated = true;
            gridViewDecimalColumn35.Name = "VatAmount";
            gridViewDecimalColumn35.Width = 80;
            gridViewDecimalColumn36.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn36.FieldName = "TotalAmount";
            gridViewDecimalColumn36.HeaderText = "Σύνολο";
            gridViewDecimalColumn36.IsAutoGenerated = true;
            gridViewDecimalColumn36.Name = "TotalAmount";
            gridViewDecimalColumn36.Width = 80;
            gridViewTextBoxColumn17.FieldName = "UserName";
            gridViewTextBoxColumn17.HeaderText = "Χρήστης";
            gridViewTextBoxColumn17.IsAutoGenerated = true;
            gridViewTextBoxColumn17.Name = "UserName";
            gridViewTextBoxColumn17.Width = 80;
            gridViewTextBoxColumn18.FieldName = "InvoiceTypeName";
            gridViewTextBoxColumn18.HeaderText = "Τύπος Παραστατικού";
            gridViewTextBoxColumn18.Name = "InvoiceTypeName";
            gridViewTextBoxColumn18.Width = 120;
            this.invoiceRadGridView.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewTextBoxColumn15,
            gridViewTextBoxColumn16,
            gridViewDateTimeColumn4,
            gridViewDecimalColumn33,
            gridViewDecimalColumn34,
            gridViewDecimalColumn35,
            gridViewDecimalColumn36,
            gridViewTextBoxColumn17,
            gridViewTextBoxColumn18});
            this.invoiceRadGridView.MasterTemplate.DataSource = this.invoiceBindingSource;
            sortDescriptor19.PropertyName = "UserName";
            groupDescriptor17.GroupNames.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor19});
            sortDescriptor20.PropertyName = "InvoiceTypeName";
            groupDescriptor18.GroupNames.AddRange(new Telerik.WinControls.Data.SortDescriptor[] {
            sortDescriptor20});
            this.invoiceRadGridView.MasterTemplate.GroupDescriptors.AddRange(new Telerik.WinControls.Data.GroupDescriptor[] {
            groupDescriptor17,
            groupDescriptor18});
            this.invoiceRadGridView.Name = "invoiceRadGridView";
            this.invoiceRadGridView.ReadOnly = true;
            this.invoiceRadGridView.ShowGroupPanel = false;
            this.invoiceRadGridView.Size = new System.Drawing.Size(983, 514);
            this.invoiceRadGridView.TabIndex = 2;
            this.invoiceRadGridView.Text = "radGridView1";
            this.invoiceRadGridView.CellDoubleClick += new Telerik.WinControls.UI.GridViewCellEventHandler(this.invoiceRadGridView_CellDoubleClick);
            // 
            // invoiceBindingSource
            // 
            this.invoiceBindingSource.DataSource = typeof(ASFuelControl.Data.Invoice);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radButton5);
            this.panel3.Controls.Add(this.radButton6);
            this.panel3.Controls.Add(this.invoiceDateTo);
            this.panel3.Controls.Add(this.radLabel5);
            this.panel3.Controls.Add(this.invoiceDateFrom);
            this.panel3.Controls.Add(this.radLabel6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(10);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(7);
            this.panel3.Size = new System.Drawing.Size(983, 51);
            this.panel3.TabIndex = 2;
            // 
            // radButton5
            // 
            this.radButton5.Dock = System.Windows.Forms.DockStyle.Right;
            this.radButton5.Image = global::ASFuelControl.Windows.Properties.Resources.Search;
            this.radButton5.Location = new System.Drawing.Point(938, 7);
            this.radButton5.Name = "radButton5";
            this.radButton5.Size = new System.Drawing.Size(38, 37);
            this.radButton5.TabIndex = 5;
            this.radButton5.Click += new System.EventHandler(this.radButton5_Click);
            // 
            // radButton6
            // 
            this.radButton6.Dock = System.Windows.Forms.DockStyle.Left;
            this.radButton6.Image = global::ASFuelControl.Windows.Properties.Resources.Search;
            this.radButton6.Location = new System.Drawing.Point(446, 7);
            this.radButton6.Name = "radButton6";
            this.radButton6.Size = new System.Drawing.Size(38, 37);
            this.radButton6.TabIndex = 4;
            this.radButton6.Click += new System.EventHandler(this.radButton6_Click);
            // 
            // invoiceDateTo
            // 
            this.invoiceDateTo.AutoSize = false;
            this.invoiceDateTo.Dock = System.Windows.Forms.DockStyle.Left;
            this.invoiceDateTo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.invoiceDateTo.Location = new System.Drawing.Point(274, 7);
            this.invoiceDateTo.Name = "invoiceDateTo";
            this.invoiceDateTo.Size = new System.Drawing.Size(172, 37);
            this.invoiceDateTo.TabIndex = 3;
            this.invoiceDateTo.TabStop = false;
            this.invoiceDateTo.Text = "Σάββατο, 7 Ιουνίου 2014";
            this.invoiceDateTo.Value = new System.DateTime(2014, 6, 7, 10, 52, 7, 271);
            // 
            // radLabel5
            // 
            this.radLabel5.AutoSize = false;
            this.radLabel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.radLabel5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.radLabel5.Location = new System.Drawing.Point(228, 7);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.radLabel5.Size = new System.Drawing.Size(46, 37);
            this.radLabel5.TabIndex = 2;
            this.radLabel5.Text = "Εώς";
            this.radLabel5.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // invoiceDateFrom
            // 
            this.invoiceDateFrom.AutoSize = false;
            this.invoiceDateFrom.Dock = System.Windows.Forms.DockStyle.Left;
            this.invoiceDateFrom.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.invoiceDateFrom.Location = new System.Drawing.Point(53, 7);
            this.invoiceDateFrom.Name = "invoiceDateFrom";
            this.invoiceDateFrom.Size = new System.Drawing.Size(175, 37);
            this.invoiceDateFrom.TabIndex = 1;
            this.invoiceDateFrom.TabStop = false;
            this.invoiceDateFrom.Text = "Σάββατο, 7 Ιουνίου 2014";
            this.invoiceDateFrom.Value = new System.DateTime(2014, 6, 7, 10, 52, 7, 271);
            // 
            // radLabel6
            // 
            this.radLabel6.AutoSize = false;
            this.radLabel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.radLabel6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.radLabel6.Location = new System.Drawing.Point(7, 7);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(46, 37);
            this.radLabel6.TabIndex = 0;
            this.radLabel6.Text = "Από";
            this.radLabel6.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Statistics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.radPageView1);
            this.Name = "Statistics";
            this.Size = new System.Drawing.Size(1004, 613);
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).EndInit();
            this.radPageView1.ResumeLayout(false);
            this.radPageViewPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.salesViewRadGridView.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesViewRadGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesViewBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesDateTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesDateFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            this.radPageViewPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingViewRadGridView.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingViewRadGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingViewBindingSource)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fillingsTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fillingsFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            this.radPageViewPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.invoiceRadGridView.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceRadGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceDateTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceDateFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadPageView radPageView1;
        private Telerik.WinControls.UI.RadPageViewPage radPageViewPage1;
        private Telerik.WinControls.UI.RadGridView salesViewRadGridView;
        private System.Windows.Forms.BindingSource salesViewBindingSource;
        private System.Windows.Forms.Panel panel1;
        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.UI.RadDateTimePicker salesDateTo;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadDateTimePicker salesDateFrom;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadPageViewPage radPageViewPage2;
        private Telerik.WinControls.UI.RadPageViewPage radPageViewPage3;
        private Telerik.WinControls.UI.RadGridView tankFillingViewRadGridView;
        private System.Windows.Forms.BindingSource tankFillingViewBindingSource;
        private System.Windows.Forms.Panel panel2;
        private Telerik.WinControls.UI.RadButton radButton3;
        private Telerik.WinControls.UI.RadButton radButton4;
        private Telerik.WinControls.UI.RadDateTimePicker fillingsTo;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadDateTimePicker fillingsFrom;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private System.Windows.Forms.Panel panel3;
        private Telerik.WinControls.UI.RadButton radButton5;
        private Telerik.WinControls.UI.RadButton radButton6;
        private Telerik.WinControls.UI.RadDateTimePicker invoiceDateTo;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadDateTimePicker invoiceDateFrom;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadGridView invoiceRadGridView;
        private System.Windows.Forms.BindingSource invoiceBindingSource;
    }
}
