﻿ALTER TABLE dbo.ApplicationUser ADD
	PasswordEncrypted ntext NULL
GO

