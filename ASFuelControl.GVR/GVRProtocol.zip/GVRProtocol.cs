﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASFuelControl.Common;
using System.IO.Ports;
using System.Threading;
using ASFuelControl.Common.Enumerators;

namespace ASFuelControl.GVR
{
    public class GVRProtocol : IFuelProtocol, IPumpDebug
    {
        private List<byte> buffer = new List<byte>();
        private List<FuelPoint> fuelPoints = new List<FuelPoint>();
        private SerialPort serialPort = new SerialPort();
        private byte[] cmd;
        private byte[] abuffer;
        private Thread th;

        private double speed { get; set; }

        public FuelPoint[] FuelPoints
        {
            get
            {
                return this.fuelPoints.ToArray();
            }
            set
            {
                this.fuelPoints = new List<FuelPoint>((IEnumerable<FuelPoint>)value);
            }
        }

        public bool IsConnected
        {
            get
            {
                return this.serialPort.IsOpen;
            }
        }

        public string CommunicationPort { get; set; }

        public event EventHandler<TotalsEventArgs> TotalsRecieved;

        public event EventHandler<FuelPointValuesArgs> DataChanged;

        public event EventHandler<FuelPointValuesArgs> DispenserStatusChanged;

        public DebugValues DebugStatusDialog(FuelPoint fp)
        {
            throw new NotImplementedException();
        }

        public void Connect()
        {
            try
            {
                this.serialPort.PortName = this.CommunicationPort;
                this.serialPort.Open();
                this.speed = (double)(1 / (this.serialPort.BaudRate / 8000));
                this.th = new Thread(new ThreadStart(this.ThreadRun));
                this.th.Start();
            }
            catch
            {
            }
        }

        public void Disconnect()
        {
            if (!this.serialPort.IsOpen)
                return;
            this.serialPort.Close();
        }

        public void AddFuelPoint(FuelPoint fp)
        {
            this.fuelPoints.Add(fp);
        }

        public void ClearFuelPoints()
        {
            this.fuelPoints.Clear();
        }

        private void ThreadRun()
        {
            foreach (FuelPoint fuelPoint in this.fuelPoints)
            {
                foreach (Nozzle nozzle in fuelPoint.Nozzles)
                    nozzle.QueryTotals = true;
            }
            while (this.IsConnected)
            {
                try
                {
                    foreach (FuelPoint fp in this.fuelPoints)
                    {
                        try
                        {
                            if (Enumerable.Count<Nozzle>(Enumerable.Where<Nozzle>((IEnumerable<Nozzle>)fp.Nozzles, (Func<Nozzle, bool>)(n => n.QueryTotals))) > 0)
                            {
                                foreach (Nozzle nz in fp.Nozzles)
                                {
                                    if (nz.QueryTotals)
                                        this.GetTotals(nz);
                                }
                            }
                            else
                            {
                                this.GetDisplay(fp);
                                if (fp.QueryAuthorize)
                                {
                                    this.SetPrice(fp.ActiveNozzle);
                                    this.Authorize(fp.ActiveNozzle);
                                }
                                else if (fp.QuerySetPrice)
                                {
                                    foreach (Nozzle nz in fp.Nozzles)
                                        this.SetPrice(nz, nz.UntiPriceInt);
                                    if (Enumerable.Count<Nozzle>(Enumerable.Where<Nozzle>((IEnumerable<Nozzle>)fp.Nozzles, (Func<Nozzle, bool>)(n => n.QuerySetPrice))) == 0)
                                        fp.QuerySetPrice = false;
                                }
                            }
                        }
                        finally
                        {
                            Thread.Sleep(100);
                        }
                    }
                }
                catch
                {
                    Thread.Sleep(200);
                }
            }
        }

        private void GetTotals(Nozzle nz)
        {
            this.cmd = new byte[6]
        {
          (byte) 170,
          (byte) 85,
          (byte) nz.ParentFuelPoint.Address,
          (byte) 7,
          (byte) 161,
          (byte) 1
        };
            this.cmd = CRC.crc(this.cmd);
            this.executeCommand(this.cmd, nz.ParentFuelPoint, ResponseL.totals, CommandType.totals);
        }

        private void SetPrice(Nozzle nozzle)
        {
            throw new NotImplementedException();
        }

        private void PresetVolume(Nozzle nz)
        {
            this.cmd = new byte[9]
        {
          (byte) 170,
          (byte) 85,
          (byte) 6,
          (byte) nz.ParentFuelPoint.Address,
          (byte) 177,
          (byte) 1,
          (byte) 0,
          (byte) 32,
          (byte) 0
        };
            this.cmd = CRC.crc(this.cmd);
            this.executeCommand(this.cmd, nz.ParentFuelPoint, ResponseL.presetVolume, CommandType.presetVolume);
        }

        private void PresetAmount(Nozzle nz)
        {
            this.cmd = new byte[9]
        {
          (byte) 170,
          (byte) 85,
          (byte) 6,
          (byte) nz.ParentFuelPoint.Address,
          (byte) 177,
          (byte) 2,
          (byte) 0,
          (byte) 32,
          (byte) 0
        };
            this.cmd = CRC.crc(this.cmd);
            this.executeCommand(this.cmd, nz.ParentFuelPoint, ResponseL.presetAmount, CommandType.presetAmount);
        }

        private void Halt(FuelPoint fp)
        {
            this.cmd = new byte[5]
        {
          (byte) 170,
          (byte) 85,
          (byte) 2,
          (byte) fp.Address,
          (byte) 181
        };
            this.cmd = CRC.crc(this.cmd);
            this.executeCommand(this.cmd, fp, ResponseL.halt, CommandType.halt);
        }

        private void Resume(FuelPoint fp)
        {
        }

        private void Authorize(Nozzle nozzle)
        {
            this.cmd = new byte[6]
        {
          (byte) 170,
          (byte) 85,
          (byte) 3,
          (byte) nozzle.ParentFuelPoint.Address,
          (byte) 178,
          (byte) 1
        };
            this.cmd = CRC.crc(this.cmd);
            this.executeCommand(this.cmd, nozzle.ParentFuelPoint, ResponseL.authorizeOrPrice, CommandType.authorize);
        }

        private void SetPrice(Nozzle nz, int unitPrice)
        {
            string str = unitPrice.ToString();
            for (int length = str.Length; length < 4; ++length)
                str = "0" + str;
            int num1 = Convert.ToInt32(str.Substring(0, 2));
            int num2 = Convert.ToInt32(str.Substring(2, 2));
            this.cmd = new byte[8]
        {
          (byte) 170,
          (byte) 85,
          (byte) nz.ParentFuelPoint.Address,
          (byte) 4,
          (byte) 193,
          (byte) 1,
          (byte) this.ith(num1),
          (byte) this.ith(num2)
        };
            this.cmd = CRC.crc(this.cmd);
            this.executeCommand(this.cmd, nz.ParentFuelPoint, ResponseL.display, CommandType.price);
        }

        private void GetDisplay(FuelPoint fp)
        {
            this.cmd = new byte[5]
        {
          (byte) 170,
          (byte) 85,
          (byte) fp.Address,
          (byte) 7,
          (byte) 160
        };
            this.cmd = CRC.crc(this.cmd);
            this.executeCommand(this.cmd, fp, ResponseL.display,CommandType.display);
        }

        private void executeCommand(byte[] cmd, FuelPoint fp, ResponseL l,CommandType t)
        {
            int num1 = 200;
            this.serialPort.Write(cmd, 0, cmd.Length);
            Thread.Sleep((int)((double)(cmd.Length + l) * this.speed));
            int num2 = 0;
            while (this.serialPort.BytesToRead > 0 && num2 < num1 / 20 * 10)
            {
                byte[] buffer = new byte[this.serialPort.BytesToRead];
                this.serialPort.Read(buffer, 0, buffer.Length);
                this.buffer.AddRange((IEnumerable<byte>)buffer);
                num2 += 10;
                Thread.Sleep(20);
            }
            if (this.buffer.ToArray().Length <= 0 || !CRC.checkcrc(this.abuffer))
                return;
            this.evaluateBuffer(this.buffer, fp, t);
        }

        private void evaluateBuffer(List<byte> response, FuelPoint fp, CommandType t)
        {
            byte[] numArray = response.ToArray();
            switch ((ResponseL)numArray.Length)
            {
                case ResponseL.authorizeOrPrice:
                    if ((int)numArray[3] != fp.Address)
                        break;
                    switch (t)
                    {
                        case CommandType.authorize:
                            fp.QueryAuthorize = false;
                            return;
                        case CommandType.price:
                            fp.QuerySetPrice = false;
                            return;
                        case CommandType.halt:
                            fp.Halted = false;
                            return;
                        default:
                            return;
                    }
                case ResponseL.display:
                    if ((int)numArray[3] != fp.Address)
                        break;
                    FuelPointStatusEnum status = fp.Status;
                    fp.Status = this.evalStatus(numArray[6]);
                    if (fp.Status == status)
                        break;
                    if (status != fp.Status && this.DispenserStatusChanged != null)
                    {
                        FuelPointValues fuelPointValues = new FuelPointValues();
                        if (fp.Status != FuelPointStatusEnum.Idle && fp.Status != FuelPointStatusEnum.Offline)
                        {
                            fp.ActiveNozzleIndex = 0;
                            fuelPointValues.ActiveNozzle = 0;
                        }
                        else
                        {
                            fp.ActiveNozzleIndex = -1;
                            fuelPointValues.ActiveNozzle = -1;
                        }
                        fuelPointValues.Status = fp.Status;
                        this.DispenserStatusChanged((object)this, new FuelPointValuesArgs()
                        {
                            CurrentFuelPoint = fp,
                            CurrentNozzleId = fuelPointValues.ActiveNozzle + 1,
                            Values = fuelPointValues
                        });
                    }
                    fp.DispensedAmount = Extensions.takeToDecimal(Extensions.skip(numArray, 11), 3) / (Decimal)Math.Pow(10.0, (double)fp.AmountDecimalPlaces);
                    fp.DispensedVolume = Extensions.takeToDecimal(Extensions.skip(numArray, 8), 3) / (Decimal)Math.Pow(10.0, (double)fp.VolumeDecimalPlaces);
                    if (this.DataChanged != null)
                        this.DataChanged((object)this, new FuelPointValuesArgs()
                        {
                            CurrentFuelPoint = fp,
                            CurrentNozzleId = 1,
                            Values = new FuelPointValues()
                            {
                                CurrentSalePrice = fp.Nozzles[0].UnitPrice,
                                CurrentPriceTotal = fp.DispensedAmount,
                                CurrentVolume = fp.DispensedVolume
                            }
                        });
                    break;
                case ResponseL.totals:
                    if ((int)numArray[3] != fp.Address)
                        break;
                    fp.Nozzles[0].TotalVolume = Extensions.takeToDecimal(Extensions.skip(numArray, 6), 5);
                    fp.Nozzles[0].TotalPrice = Extensions.takeToDecimal(Extensions.skip(numArray, 11), 5);
                    fp.Initialized = true;
                    if (this.TotalsRecieved == null)
                        break;
                    this.TotalsRecieved((object)this, new TotalsEventArgs(fp, fp.Nozzles[0].Index, fp.Nozzles[0].TotalVolume, fp.Nozzles[0].TotalPrice));
                    break;
            }
        }

        private FuelPointStatusEnum evalStatus(byte p)
        {
            switch (p)
            {
                case (byte)0:
                    return FuelPointStatusEnum.Idle;
                case (byte)1:
                    return FuelPointStatusEnum.Ready;
                case (byte)2:
                    return FuelPointStatusEnum.Nozzle;
                case (byte)4:
                    return FuelPointStatusEnum.Work;
                default:
                    return FuelPointStatusEnum.Offline;
            }
        }

        private int ith(int num)
        {
            return 16 * (num / 10) + num % 10;
        }

        private enum CommandType
        {
            display = 1,
            totals = 2,
            authorize = 3,
            price = 4,
            halt = 5,
            resume = 6,
            presetVolume = 7,
            presetAmount = 8,
        }

        private enum ResponseL
        {
            authorizeOrPrice = 7,
            halt = 8,
            stop = 9,
            presetVolume = 10,
            presetAmount = 11,
            display = 16,
            totals = 23,
        }
    }
}
