﻿namespace ASFuelControl.Windows.UI.Forms
{
    partial class DispenserTransactionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn1 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn2 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewDateTimeColumn gridViewDateTimeColumn1 = new Telerik.WinControls.UI.GridViewDateTimeColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn3 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn1 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn2 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn3 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewCommandColumn gridViewCommandColumn1 = new Telerik.WinControls.UI.GridViewCommandColumn();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DispenserTransactionsForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.radButton3 = new Telerik.WinControls.UI.RadButton();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radDropDownList1 = new Telerik.WinControls.UI.RadDropDownList();
            this.radDateTimePicker2 = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radDateTimePicker1 = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.salesTransactionRadGridView = new Telerik.WinControls.UI.RadGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDropDownList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePicker2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePicker1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesTransactionRadGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesTransactionRadGridView.MasterTemplate)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radButton3);
            this.panel1.Controls.Add(this.radButton1);
            this.panel1.Controls.Add(this.radLabel3);
            this.panel1.Controls.Add(this.radDropDownList1);
            this.panel1.Controls.Add(this.radDateTimePicker2);
            this.panel1.Controls.Add(this.radLabel2);
            this.panel1.Controls.Add(this.radDateTimePicker1);
            this.panel1.Controls.Add(this.radLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(744, 37);
            this.panel1.TabIndex = 0;
            // 
            // radButton3
            // 
            this.radButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radButton3.DisplayStyle = Telerik.WinControls.DisplayStyle.Image;
            this.radButton3.Image = global::ASFuelControl.Windows.Properties.Resources.Printer;
            this.radButton3.Location = new System.Drawing.Point(700, 2);
            this.radButton3.Name = "radButton3";
            this.radButton3.Size = new System.Drawing.Size(41, 34);
            this.radButton3.TabIndex = 7;
            this.radButton3.Text = "radButton3";
            this.radButton3.Click += new System.EventHandler(this.radButton3_Click);
            // 
            // radButton1
            // 
            this.radButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radButton1.DisplayStyle = Telerik.WinControls.DisplayStyle.Image;
            this.radButton1.Image = global::ASFuelControl.Windows.Properties.Resources.Search;
            this.radButton1.Location = new System.Drawing.Point(653, 2);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(41, 34);
            this.radButton1.TabIndex = 6;
            this.radButton1.Text = "radButton1";
            this.radButton1.Click += new System.EventHandler(this.radButton1_Click);
            // 
            // radLabel3
            // 
            this.radLabel3.Location = new System.Drawing.Point(381, 10);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(76, 18);
            this.radLabel3.TabIndex = 5;
            this.radLabel3.Text = "Ακροσωλήνιο";
            // 
            // radDropDownList1
            // 
            this.radDropDownList1.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            this.radDropDownList1.Location = new System.Drawing.Point(463, 9);
            this.radDropDownList1.Name = "radDropDownList1";
            this.radDropDownList1.Size = new System.Drawing.Size(151, 20);
            this.radDropDownList1.TabIndex = 4;
            this.radDropDownList1.Text = "radDropDownList1";
            // 
            // radDateTimePicker2
            // 
            this.radDateTimePicker2.CustomFormat = "dd/MM/yyyy HH:mm";
            this.radDateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.radDateTimePicker2.Location = new System.Drawing.Point(224, 9);
            this.radDateTimePicker2.Name = "radDateTimePicker2";
            this.radDateTimePicker2.Size = new System.Drawing.Size(124, 20);
            this.radDateTimePicker2.TabIndex = 3;
            this.radDateTimePicker2.TabStop = false;
            this.radDateTimePicker2.Text = "22/07/2014 10:22";
            this.radDateTimePicker2.Value = new System.DateTime(2014, 7, 22, 10, 22, 19, 910);
            // 
            // radLabel2
            // 
            this.radLabel2.Location = new System.Drawing.Point(191, 10);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(26, 18);
            this.radLabel2.TabIndex = 2;
            this.radLabel2.Text = "Εώς";
            // 
            // radDateTimePicker1
            // 
            this.radDateTimePicker1.CustomFormat = "dd/MM/yyyy HH:mm";
            this.radDateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.radDateTimePicker1.Location = new System.Drawing.Point(45, 9);
            this.radDateTimePicker1.Name = "radDateTimePicker1";
            this.radDateTimePicker1.Size = new System.Drawing.Size(124, 20);
            this.radDateTimePicker1.TabIndex = 1;
            this.radDateTimePicker1.TabStop = false;
            this.radDateTimePicker1.Text = "22/07/2014 10:22";
            this.radDateTimePicker1.Value = new System.DateTime(2014, 7, 22, 10, 22, 19, 910);
            // 
            // radLabel1
            // 
            this.radLabel1.Location = new System.Drawing.Point(12, 10);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(27, 18);
            this.radLabel1.TabIndex = 0;
            this.radLabel1.Text = "Από";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radButton2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 425);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(744, 37);
            this.panel2.TabIndex = 1;
            // 
            // radButton2
            // 
            this.radButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radButton2.DisplayStyle = Telerik.WinControls.DisplayStyle.Text;
            this.radButton2.Image = global::ASFuelControl.Windows.Properties.Resources.Search;
            this.radButton2.Location = new System.Drawing.Point(615, 3);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(126, 31);
            this.radButton2.TabIndex = 7;
            this.radButton2.Text = "Εντάξει";
            // 
            // salesTransactionRadGridView
            // 
            this.salesTransactionRadGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.salesTransactionRadGridView.Location = new System.Drawing.Point(0, 37);
            // 
            // salesTransactionRadGridView
            // 
            this.salesTransactionRadGridView.MasterTemplate.AllowAddNewRow = false;
            this.salesTransactionRadGridView.MasterTemplate.AllowDeleteRow = false;
            gridViewTextBoxColumn1.FieldName = "NozzleNumber";
            gridViewTextBoxColumn1.HeaderText = "Α/Σ";
            gridViewTextBoxColumn1.Name = "column6";
            gridViewTextBoxColumn1.Width = 30;
            gridViewTextBoxColumn2.FieldName = "FuelType";
            gridViewTextBoxColumn2.HeaderText = "Καύσιμο";
            gridViewTextBoxColumn2.Name = "column7";
            gridViewTextBoxColumn2.Width = 150;
            gridViewDateTimeColumn1.FieldName = "TransactionDate";
            gridViewDateTimeColumn1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            gridViewDateTimeColumn1.FormatString = "{0:dd/MM/yyyy HH:mm}";
            gridViewDateTimeColumn1.HeaderText = "Ημερομηνία";
            gridViewDateTimeColumn1.Name = "column1";
            gridViewDateTimeColumn1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            gridViewDateTimeColumn1.Width = 150;
            gridViewTextBoxColumn3.FieldName = "InvoiceData";
            gridViewTextBoxColumn3.HeaderText = "Παραστατικό";
            gridViewTextBoxColumn3.Name = "column2";
            gridViewTextBoxColumn3.Width = 110;
            gridViewDecimalColumn1.FieldName = "TotalVolume";
            gridViewDecimalColumn1.HeaderText = "Ποσότητα";
            gridViewDecimalColumn1.Name = "TotalVolume";
            gridViewDecimalColumn1.Width = 70;
            gridViewDecimalColumn2.DecimalPlaces = 3;
            gridViewDecimalColumn2.FieldName = "UnitPrice";
            gridViewDecimalColumn2.HeaderText = "€/Lt";
            gridViewDecimalColumn2.Name = "UnitPrice";
            gridViewDecimalColumn2.Width = 70;
            gridViewDecimalColumn3.FieldName = "TotalPrice";
            gridViewDecimalColumn3.HeaderText = "Σύνολο";
            gridViewDecimalColumn3.Name = "TotalPrice";
            gridViewDecimalColumn3.Width = 80;
            gridViewCommandColumn1.HeaderText = "";
            gridViewCommandColumn1.Image = global::ASFuelControl.Windows.Properties.Resources.Printer_small;
            gridViewCommandColumn1.ImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            gridViewCommandColumn1.IsPinned = true;
            gridViewCommandColumn1.Name = "ReprintCommand";
            gridViewCommandColumn1.PinPosition = Telerik.WinControls.UI.PinnedColumnPosition.Right;
            gridViewCommandColumn1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            gridViewCommandColumn1.Width = 25;
            this.salesTransactionRadGridView.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewTextBoxColumn1,
            gridViewTextBoxColumn2,
            gridViewDateTimeColumn1,
            gridViewTextBoxColumn3,
            gridViewDecimalColumn1,
            gridViewDecimalColumn2,
            gridViewDecimalColumn3,
            gridViewCommandColumn1});
            this.salesTransactionRadGridView.Name = "salesTransactionRadGridView";
            this.salesTransactionRadGridView.ReadOnly = true;
            this.salesTransactionRadGridView.ShowGroupPanel = false;
            this.salesTransactionRadGridView.Size = new System.Drawing.Size(744, 388);
            this.salesTransactionRadGridView.TabIndex = 3;
            this.salesTransactionRadGridView.Text = "radGridView1";
            this.salesTransactionRadGridView.ViewCellFormatting += new Telerik.WinControls.UI.CellFormattingEventHandler(this.salesTransactionRadGridView_ViewCellFormatting);
            this.salesTransactionRadGridView.CommandCellClick += new Telerik.WinControls.UI.CommandCellClickEventHandler(this.salesTransactionRadGridView_CommandCellClick);
            // 
            // DispenserTransactionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 462);
            this.Controls.Add(this.salesTransactionRadGridView);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(760, 500);
            this.Name = "DispenserTransactionsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Πωλήσεις Αντλίας";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDropDownList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePicker2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePicker1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesTransactionRadGridView.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesTransactionRadGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadDropDownList radDropDownList1;
        private Telerik.WinControls.UI.RadDateTimePicker radDateTimePicker2;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadDateTimePicker radDateTimePicker1;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private System.Windows.Forms.Panel panel2;
        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadGridView salesTransactionRadGridView;
        private Telerik.WinControls.UI.RadButton radButton3;
    }
}