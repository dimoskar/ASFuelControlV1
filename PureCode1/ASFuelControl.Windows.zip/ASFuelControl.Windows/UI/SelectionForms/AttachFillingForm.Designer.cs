﻿namespace ASFuelControl.Windows.UI.SelectionForms
{
    partial class AttachFillingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn1 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn1 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn2 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewCommandColumn gridViewCommandColumn1 = new Telerik.WinControls.UI.GridViewCommandColumn();
            Telerik.WinControls.UI.GridViewDateTimeColumn gridViewDateTimeColumn1 = new Telerik.WinControls.UI.GridViewDateTimeColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn3 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn4 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn5 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn6 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn7 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn8 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDateTimeColumn gridViewDateTimeColumn2 = new Telerik.WinControls.UI.GridViewDateTimeColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn9 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn10 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn11 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn12 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn13 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn14 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewDateTimeColumn gridViewDateTimeColumn3 = new Telerik.WinControls.UI.GridViewDateTimeColumn();
            Telerik.WinControls.UI.GridViewDecimalColumn gridViewDecimalColumn15 = new Telerik.WinControls.UI.GridViewDecimalColumn();
            Telerik.WinControls.UI.GridViewCommandColumn gridViewCommandColumn2 = new Telerik.WinControls.UI.GridViewCommandColumn();
            Telerik.WinControls.UI.GridViewCommandColumn gridViewCommandColumn3 = new Telerik.WinControls.UI.GridViewCommandColumn();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AttachFillingForm));
            this.radSplitContainer1 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel1 = new Telerik.WinControls.UI.SplitPanel();
            this.invoiceLineRadGridView = new Telerik.WinControls.UI.RadGridView();
            this.invoiceLineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.splitPanel2 = new Telerik.WinControls.UI.SplitPanel();
            this.radSplitContainer2 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel4 = new Telerik.WinControls.UI.SplitPanel();
            this.tankFillingRadGridView = new Telerik.WinControls.UI.RadGridView();
            this.tankFillingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.radCheckBox1 = new Telerik.WinControls.UI.RadCheckBox();
            this.splitPanel5 = new Telerik.WinControls.UI.SplitPanel();
            this.radGridView1 = new Telerik.WinControls.UI.RadGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radCheckBox2 = new Telerik.WinControls.UI.RadCheckBox();
            this.splitPanel3 = new Telerik.WinControls.UI.SplitPanel();
            this.tankLevelStartViewRadGridView = new Telerik.WinControls.UI.RadGridView();
            this.tankLevelStartViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radDateTimePicker2 = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radDateTimePicker1 = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radDropDownList1 = new Telerik.WinControls.UI.RadDropDownList();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).BeginInit();
            this.radSplitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).BeginInit();
            this.splitPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceLineRadGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceLineRadGridView.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceLineBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).BeginInit();
            this.splitPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer2)).BeginInit();
            this.radSplitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel4)).BeginInit();
            this.splitPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingRadGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingRadGridView.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingBindingSource)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel5)).BeginInit();
            this.splitPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel3)).BeginInit();
            this.splitPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tankLevelStartViewRadGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankLevelStartViewRadGridView.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankLevelStartViewBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePicker2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePicker1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDropDownList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radSplitContainer1
            // 
            this.radSplitContainer1.Controls.Add(this.splitPanel1);
            this.radSplitContainer1.Controls.Add(this.splitPanel2);
            this.radSplitContainer1.Controls.Add(this.splitPanel3);
            this.radSplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radSplitContainer1.Location = new System.Drawing.Point(0, 46);
            this.radSplitContainer1.Name = "radSplitContainer1";
            // 
            // 
            // 
            this.radSplitContainer1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer1.Size = new System.Drawing.Size(1116, 470);
            this.radSplitContainer1.SplitterWidth = 4;
            this.radSplitContainer1.TabIndex = 0;
            this.radSplitContainer1.TabStop = false;
            this.radSplitContainer1.Text = "radSplitContainer1";
            // 
            // splitPanel1
            // 
            this.splitPanel1.AutoScroll = true;
            this.splitPanel1.Controls.Add(this.invoiceLineRadGridView);
            this.splitPanel1.Location = new System.Drawing.Point(0, 0);
            this.splitPanel1.Name = "splitPanel1";
            // 
            // 
            // 
            this.splitPanel1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel1.Size = new System.Drawing.Size(369, 470);
            this.splitPanel1.TabIndex = 0;
            this.splitPanel1.TabStop = false;
            this.splitPanel1.Text = "splitPanel1";
            // 
            // invoiceLineRadGridView
            // 
            this.invoiceLineRadGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.invoiceLineRadGridView.Location = new System.Drawing.Point(0, 0);
            // 
            // invoiceLineRadGridView
            // 
            this.invoiceLineRadGridView.MasterTemplate.AllowAddNewRow = false;
            this.invoiceLineRadGridView.MasterTemplate.AllowDeleteRow = false;
            this.invoiceLineRadGridView.MasterTemplate.AutoGenerateColumns = false;
            gridViewTextBoxColumn1.FieldName = "Invoice.Description";
            gridViewTextBoxColumn1.HeaderText = "Παραστατικό";
            gridViewTextBoxColumn1.IsAutoGenerated = true;
            gridViewTextBoxColumn1.Name = "InvoiceId";
            gridViewTextBoxColumn1.Width = 150;
            gridViewDecimalColumn1.FieldName = "Volume";
            gridViewDecimalColumn1.HeaderText = "Όγκος";
            gridViewDecimalColumn1.IsAutoGenerated = true;
            gridViewDecimalColumn1.Name = "Volume";
            gridViewDecimalColumn1.Width = 80;
            gridViewDecimalColumn2.FieldName = "VolumeNormalized";
            gridViewDecimalColumn2.HeaderText = "Ογκος 15";
            gridViewDecimalColumn2.IsAutoGenerated = true;
            gridViewDecimalColumn2.Name = "VolumeNormalized";
            gridViewDecimalColumn2.Width = 80;
            gridViewCommandColumn1.DefaultText = "Χρήση";
            gridViewCommandColumn1.HeaderText = "";
            gridViewCommandColumn1.Name = "column1";
            gridViewCommandColumn1.UseDefaultText = true;
            gridViewCommandColumn1.Width = 60;
            this.invoiceLineRadGridView.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewTextBoxColumn1,
            gridViewDecimalColumn1,
            gridViewDecimalColumn2,
            gridViewCommandColumn1});
            this.invoiceLineRadGridView.MasterTemplate.DataSource = this.invoiceLineBindingSource;
            this.invoiceLineRadGridView.Name = "invoiceLineRadGridView";
            this.invoiceLineRadGridView.ReadOnly = true;
            this.invoiceLineRadGridView.ShowGroupPanel = false;
            this.invoiceLineRadGridView.Size = new System.Drawing.Size(369, 470);
            this.invoiceLineRadGridView.TabIndex = 0;
            this.invoiceLineRadGridView.Text = "radGridView1";
            this.invoiceLineRadGridView.CommandCellClick += new Telerik.WinControls.UI.CommandCellClickEventHandler(this.invoiceLineRadGridView_CommandCellClick);
            // 
            // invoiceLineBindingSource
            // 
            this.invoiceLineBindingSource.DataSource = typeof(ASFuelControl.Data.InvoiceLine);
            // 
            // splitPanel2
            // 
            this.splitPanel2.Controls.Add(this.radSplitContainer2);
            this.splitPanel2.Location = new System.Drawing.Point(373, 0);
            this.splitPanel2.Name = "splitPanel2";
            // 
            // 
            // 
            this.splitPanel2.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel2.Size = new System.Drawing.Size(369, 470);
            this.splitPanel2.SizeInfo.AbsoluteSize = new System.Drawing.Size(100, 200);
            this.splitPanel2.TabIndex = 1;
            this.splitPanel2.TabStop = false;
            this.splitPanel2.Text = "splitPanel2";
            // 
            // radSplitContainer2
            // 
            this.radSplitContainer2.Controls.Add(this.splitPanel4);
            this.radSplitContainer2.Controls.Add(this.splitPanel5);
            this.radSplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radSplitContainer2.Location = new System.Drawing.Point(0, 0);
            this.radSplitContainer2.Name = "radSplitContainer2";
            this.radSplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // 
            // 
            this.radSplitContainer2.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer2.Size = new System.Drawing.Size(369, 470);
            this.radSplitContainer2.SplitterWidth = 4;
            this.radSplitContainer2.TabIndex = 1;
            this.radSplitContainer2.TabStop = false;
            this.radSplitContainer2.Text = "radSplitContainer2";
            // 
            // splitPanel4
            // 
            this.splitPanel4.Controls.Add(this.tankFillingRadGridView);
            this.splitPanel4.Controls.Add(this.panel3);
            this.splitPanel4.Location = new System.Drawing.Point(0, 0);
            this.splitPanel4.Name = "splitPanel4";
            // 
            // 
            // 
            this.splitPanel4.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel4.Size = new System.Drawing.Size(369, 233);
            this.splitPanel4.TabIndex = 0;
            this.splitPanel4.TabStop = false;
            this.splitPanel4.Text = "splitPanel4";
            // 
            // tankFillingRadGridView
            // 
            this.tankFillingRadGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tankFillingRadGridView.Location = new System.Drawing.Point(0, 26);
            // 
            // tankFillingRadGridView
            // 
            this.tankFillingRadGridView.MasterTemplate.AllowAddNewRow = false;
            this.tankFillingRadGridView.MasterTemplate.AllowDeleteRow = false;
            this.tankFillingRadGridView.MasterTemplate.AutoGenerateColumns = false;
            gridViewDateTimeColumn1.FieldName = "TransactionTime";
            gridViewDateTimeColumn1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            gridViewDateTimeColumn1.FormatString = "{0:dd/MM/yyyy HH:mm}";
            gridViewDateTimeColumn1.HeaderText = "Ημερ/νια - Ωρα";
            gridViewDateTimeColumn1.IsAutoGenerated = true;
            gridViewDateTimeColumn1.Name = "TransactionTime";
            gridViewDateTimeColumn1.Width = 80;
            gridViewDecimalColumn3.FieldName = "VolumeReal";
            gridViewDecimalColumn3.HeaderText = "Πραγμ. Όγκος ";
            gridViewDecimalColumn3.IsAutoGenerated = true;
            gridViewDecimalColumn3.Name = "VolumeReal";
            gridViewDecimalColumn3.Width = 80;
            gridViewDecimalColumn4.FieldName = "VolumeRealNormalized";
            gridViewDecimalColumn4.HeaderText = "Πραγμ. Όγκος 15";
            gridViewDecimalColumn4.IsAutoGenerated = true;
            gridViewDecimalColumn4.Name = "VolumeRealNormalized";
            gridViewDecimalColumn4.Width = 80;
            gridViewDecimalColumn5.FieldName = "Volume";
            gridViewDecimalColumn5.HeaderText = "Όγκος";
            gridViewDecimalColumn5.IsAutoGenerated = true;
            gridViewDecimalColumn5.Name = "Volume";
            gridViewDecimalColumn5.Width = 80;
            gridViewDecimalColumn6.FieldName = "VolumeNormalized";
            gridViewDecimalColumn6.HeaderText = "Όγκος 15";
            gridViewDecimalColumn6.IsAutoGenerated = true;
            gridViewDecimalColumn6.Name = "VolumeNormalized";
            gridViewDecimalColumn6.Width = 80;
            gridViewDecimalColumn7.FieldName = "LevelStart";
            gridViewDecimalColumn7.HeaderText = "Σταθμη Εναρξης";
            gridViewDecimalColumn7.IsAutoGenerated = true;
            gridViewDecimalColumn7.Name = "LevelStart";
            gridViewDecimalColumn7.Width = 80;
            gridViewDecimalColumn8.FieldName = "LevelEnd";
            gridViewDecimalColumn8.HeaderText = "Στάθμη Τέλους";
            gridViewDecimalColumn8.IsAutoGenerated = true;
            gridViewDecimalColumn8.Name = "LevelEnd";
            gridViewDecimalColumn8.Width = 80;
            this.tankFillingRadGridView.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewDateTimeColumn1,
            gridViewDecimalColumn3,
            gridViewDecimalColumn4,
            gridViewDecimalColumn5,
            gridViewDecimalColumn6,
            gridViewDecimalColumn7,
            gridViewDecimalColumn8});
            this.tankFillingRadGridView.MasterTemplate.DataSource = this.tankFillingBindingSource;
            this.tankFillingRadGridView.Name = "tankFillingRadGridView";
            this.tankFillingRadGridView.ReadOnly = true;
            this.tankFillingRadGridView.ShowGroupPanel = false;
            this.tankFillingRadGridView.Size = new System.Drawing.Size(369, 207);
            this.tankFillingRadGridView.TabIndex = 0;
            this.tankFillingRadGridView.Text = "radGridView1";
            // 
            // tankFillingBindingSource
            // 
            this.tankFillingBindingSource.DataSource = typeof(ASFuelControl.Data.TankFilling);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radCheckBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(369, 26);
            this.panel3.TabIndex = 1;
            // 
            // radCheckBox1
            // 
            this.radCheckBox1.AutoSize = false;
            this.radCheckBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.radCheckBox1.Location = new System.Drawing.Point(0, 0);
            this.radCheckBox1.Name = "radCheckBox1";
            this.radCheckBox1.Size = new System.Drawing.Size(138, 26);
            this.radCheckBox1.TabIndex = 0;
            this.radCheckBox1.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            this.radCheckBox1.ToggleStateChanging += new Telerik.WinControls.UI.StateChangingEventHandler(this.radCheckBox1_ToggleStateChanging);
            this.radCheckBox1.Click += new System.EventHandler(this.radCheckBox1_Click);
            // 
            // splitPanel5
            // 
            this.splitPanel5.Controls.Add(this.radGridView1);
            this.splitPanel5.Controls.Add(this.panel2);
            this.splitPanel5.Location = new System.Drawing.Point(0, 237);
            this.splitPanel5.Name = "splitPanel5";
            // 
            // 
            // 
            this.splitPanel5.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel5.Size = new System.Drawing.Size(369, 233);
            this.splitPanel5.TabIndex = 1;
            this.splitPanel5.TabStop = false;
            this.splitPanel5.Text = "splitPanel5";
            // 
            // radGridView1
            // 
            this.radGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radGridView1.Location = new System.Drawing.Point(0, 26);
            // 
            // radGridView1
            // 
            this.radGridView1.MasterTemplate.AllowAddNewRow = false;
            this.radGridView1.MasterTemplate.AllowDeleteRow = false;
            this.radGridView1.MasterTemplate.AutoGenerateColumns = false;
            gridViewDateTimeColumn2.FieldName = "TransactionTime";
            gridViewDateTimeColumn2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            gridViewDateTimeColumn2.FormatString = "{0:dd/MM/yyyy HH:mm}";
            gridViewDateTimeColumn2.HeaderText = "Ημερ/νια - Ωρα";
            gridViewDateTimeColumn2.IsAutoGenerated = true;
            gridViewDateTimeColumn2.Name = "TransactionTime";
            gridViewDateTimeColumn2.Width = 80;
            gridViewDecimalColumn9.FieldName = "VolumeReal";
            gridViewDecimalColumn9.HeaderText = "Πραγμ. Όγκος ";
            gridViewDecimalColumn9.IsAutoGenerated = true;
            gridViewDecimalColumn9.Name = "VolumeReal";
            gridViewDecimalColumn9.Width = 80;
            gridViewDecimalColumn10.FieldName = "VolumeRealNormalized";
            gridViewDecimalColumn10.HeaderText = "Πραγμ. Όγκος 15";
            gridViewDecimalColumn10.IsAutoGenerated = true;
            gridViewDecimalColumn10.Name = "VolumeRealNormalized";
            gridViewDecimalColumn10.Width = 80;
            gridViewDecimalColumn11.FieldName = "Volume";
            gridViewDecimalColumn11.HeaderText = "Όγκος";
            gridViewDecimalColumn11.IsAutoGenerated = true;
            gridViewDecimalColumn11.Name = "Volume";
            gridViewDecimalColumn11.Width = 80;
            gridViewDecimalColumn12.FieldName = "VolumeNormalized";
            gridViewDecimalColumn12.HeaderText = "Όγκος 15";
            gridViewDecimalColumn12.IsAutoGenerated = true;
            gridViewDecimalColumn12.Name = "VolumeNormalized";
            gridViewDecimalColumn12.Width = 80;
            gridViewDecimalColumn13.FieldName = "LevelStart";
            gridViewDecimalColumn13.HeaderText = "Σταθμη Εναρξης";
            gridViewDecimalColumn13.IsAutoGenerated = true;
            gridViewDecimalColumn13.Name = "LevelStart";
            gridViewDecimalColumn13.Width = 80;
            gridViewDecimalColumn14.FieldName = "LevelEnd";
            gridViewDecimalColumn14.HeaderText = "Στάθμη Τέλους";
            gridViewDecimalColumn14.IsAutoGenerated = true;
            gridViewDecimalColumn14.Name = "LevelEnd";
            gridViewDecimalColumn14.Width = 80;
            this.radGridView1.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewDateTimeColumn2,
            gridViewDecimalColumn9,
            gridViewDecimalColumn10,
            gridViewDecimalColumn11,
            gridViewDecimalColumn12,
            gridViewDecimalColumn13,
            gridViewDecimalColumn14});
            this.radGridView1.MasterTemplate.DataSource = this.tankFillingBindingSource;
            this.radGridView1.Name = "radGridView1";
            this.radGridView1.ReadOnly = true;
            this.radGridView1.ShowGroupPanel = false;
            this.radGridView1.Size = new System.Drawing.Size(369, 207);
            this.radGridView1.TabIndex = 1;
            this.radGridView1.Text = "radGridView1";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radCheckBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(369, 26);
            this.panel2.TabIndex = 0;
            // 
            // radCheckBox2
            // 
            this.radCheckBox2.AutoSize = false;
            this.radCheckBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.radCheckBox2.Location = new System.Drawing.Point(0, 0);
            this.radCheckBox2.Name = "radCheckBox2";
            this.radCheckBox2.Size = new System.Drawing.Size(138, 26);
            this.radCheckBox2.TabIndex = 1;
            this.radCheckBox2.ToggleStateChanging += new Telerik.WinControls.UI.StateChangingEventHandler(this.radCheckBox2_ToggleStateChanging);
            this.radCheckBox2.Click += new System.EventHandler(this.radCheckBox2_Click);
            // 
            // splitPanel3
            // 
            this.splitPanel3.AutoScroll = true;
            this.splitPanel3.Controls.Add(this.tankLevelStartViewRadGridView);
            this.splitPanel3.Location = new System.Drawing.Point(746, 0);
            this.splitPanel3.Name = "splitPanel3";
            // 
            // 
            // 
            this.splitPanel3.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel3.Size = new System.Drawing.Size(370, 470);
            this.splitPanel3.TabIndex = 2;
            this.splitPanel3.TabStop = false;
            this.splitPanel3.Text = "splitPanel3";
            // 
            // tankLevelStartViewRadGridView
            // 
            this.tankLevelStartViewRadGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tankLevelStartViewRadGridView.Location = new System.Drawing.Point(0, 0);
            // 
            // tankLevelStartViewRadGridView
            // 
            this.tankLevelStartViewRadGridView.MasterTemplate.AllowAddNewRow = false;
            this.tankLevelStartViewRadGridView.MasterTemplate.AllowDeleteRow = false;
            this.tankLevelStartViewRadGridView.MasterTemplate.AutoGenerateColumns = false;
            gridViewDateTimeColumn3.FieldName = "TansDate";
            gridViewDateTimeColumn3.HeaderText = "Ημερομηνία";
            gridViewDateTimeColumn3.IsAutoGenerated = true;
            gridViewDateTimeColumn3.Name = "TansDate";
            gridViewDateTimeColumn3.Width = 100;
            gridViewDecimalColumn15.DataType = typeof(System.Nullable<decimal>);
            gridViewDecimalColumn15.FieldName = "Level";
            gridViewDecimalColumn15.HeaderText = "Στάθμη";
            gridViewDecimalColumn15.IsAutoGenerated = true;
            gridViewDecimalColumn15.Name = "Level";
            gridViewDecimalColumn15.Width = 80;
            gridViewCommandColumn2.DefaultText = "Χρήση Εναρξης";
            gridViewCommandColumn2.HeaderText = "";
            gridViewCommandColumn2.Name = "column1";
            gridViewCommandColumn2.UseDefaultText = true;
            gridViewCommandColumn2.Width = 60;
            gridViewCommandColumn3.DefaultText = "Χρήση Λήξης";
            gridViewCommandColumn3.HeaderText = "";
            gridViewCommandColumn3.Name = "column2";
            gridViewCommandColumn3.UseDefaultText = true;
            gridViewCommandColumn3.Width = 60;
            this.tankLevelStartViewRadGridView.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewDateTimeColumn3,
            gridViewDecimalColumn15,
            gridViewCommandColumn2,
            gridViewCommandColumn3});
            this.tankLevelStartViewRadGridView.MasterTemplate.DataSource = this.tankLevelStartViewBindingSource;
            this.tankLevelStartViewRadGridView.Name = "tankLevelStartViewRadGridView";
            this.tankLevelStartViewRadGridView.ReadOnly = true;
            this.tankLevelStartViewRadGridView.ShowGroupPanel = false;
            this.tankLevelStartViewRadGridView.Size = new System.Drawing.Size(370, 470);
            this.tankLevelStartViewRadGridView.TabIndex = 0;
            this.tankLevelStartViewRadGridView.Text = "radGridView1";
            this.tankLevelStartViewRadGridView.CommandCellClick += new Telerik.WinControls.UI.CommandCellClickEventHandler(this.tankLevelStartViewRadGridView_CommandCellClick);
            // 
            // tankLevelStartViewBindingSource
            // 
            this.tankLevelStartViewBindingSource.DataSource = typeof(ASFuelControl.Data.TankLevelStartView);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radButton2);
            this.panel1.Controls.Add(this.radButton1);
            this.panel1.Controls.Add(this.radLabel3);
            this.panel1.Controls.Add(this.radDateTimePicker2);
            this.panel1.Controls.Add(this.radLabel2);
            this.panel1.Controls.Add(this.radLabel1);
            this.panel1.Controls.Add(this.radDateTimePicker1);
            this.panel1.Controls.Add(this.radDropDownList1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1116, 46);
            this.panel1.TabIndex = 1;
            // 
            // radButton2
            // 
            this.radButton2.Location = new System.Drawing.Point(664, 11);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(110, 24);
            this.radButton2.TabIndex = 7;
            this.radButton2.Text = "Αποθήκευση";
            this.radButton2.Click += new System.EventHandler(this.radButton2_Click);
            // 
            // radButton1
            // 
            this.radButton1.Location = new System.Drawing.Point(548, 11);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(110, 24);
            this.radButton1.TabIndex = 6;
            this.radButton1.Text = "Εύρεση";
            this.radButton1.Click += new System.EventHandler(this.radButton1_Click);
            // 
            // radLabel3
            // 
            this.radLabel3.Location = new System.Drawing.Point(396, 13);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(26, 18);
            this.radLabel3.TabIndex = 5;
            this.radLabel3.Text = "Εώς";
            // 
            // radDateTimePicker2
            // 
            this.radDateTimePicker2.CustomFormat = "dd/MM/yyyy";
            this.radDateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.radDateTimePicker2.Location = new System.Drawing.Point(435, 12);
            this.radDateTimePicker2.Name = "radDateTimePicker2";
            this.radDateTimePicker2.Size = new System.Drawing.Size(91, 20);
            this.radDateTimePicker2.TabIndex = 4;
            this.radDateTimePicker2.TabStop = false;
            this.radDateTimePicker2.Text = "07/09/2014";
            this.radDateTimePicker2.Value = new System.DateTime(2014, 9, 7, 19, 15, 13, 657);
            // 
            // radLabel2
            // 
            this.radLabel2.Location = new System.Drawing.Point(247, 13);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(27, 18);
            this.radLabel2.TabIndex = 3;
            this.radLabel2.Text = "Από";
            // 
            // radLabel1
            // 
            this.radLabel1.Location = new System.Drawing.Point(13, 13);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(54, 18);
            this.radLabel1.TabIndex = 2;
            this.radLabel1.Text = "Δεξαμενή";
            // 
            // radDateTimePicker1
            // 
            this.radDateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.radDateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.radDateTimePicker1.Location = new System.Drawing.Point(286, 12);
            this.radDateTimePicker1.Name = "radDateTimePicker1";
            this.radDateTimePicker1.Size = new System.Drawing.Size(91, 20);
            this.radDateTimePicker1.TabIndex = 1;
            this.radDateTimePicker1.TabStop = false;
            this.radDateTimePicker1.Text = "07/09/2014";
            this.radDateTimePicker1.Value = new System.DateTime(2014, 9, 7, 19, 15, 13, 657);
            // 
            // radDropDownList1
            // 
            this.radDropDownList1.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            this.radDropDownList1.Location = new System.Drawing.Point(72, 12);
            this.radDropDownList1.Name = "radDropDownList1";
            this.radDropDownList1.Size = new System.Drawing.Size(155, 20);
            this.radDropDownList1.TabIndex = 0;
            this.radDropDownList1.Text = "radDropDownList1";
            // 
            // AttachFillingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 516);
            this.Controls.Add(this.radSplitContainer1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AttachFillingForm";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "AttachFillingForm";
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).EndInit();
            this.radSplitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).EndInit();
            this.splitPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.invoiceLineRadGridView.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceLineRadGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceLineBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).EndInit();
            this.splitPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer2)).EndInit();
            this.radSplitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel4)).EndInit();
            this.splitPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingRadGridView.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingRadGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankFillingBindingSource)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel5)).EndInit();
            this.splitPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel3)).EndInit();
            this.splitPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tankLevelStartViewRadGridView.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankLevelStartViewRadGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tankLevelStartViewBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePicker2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePicker1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDropDownList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer1;
        private Telerik.WinControls.UI.SplitPanel splitPanel1;
        private Telerik.WinControls.UI.SplitPanel splitPanel2;
        private Telerik.WinControls.UI.SplitPanel splitPanel3;
        private System.Windows.Forms.Panel panel1;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadDateTimePicker radDateTimePicker2;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadDateTimePicker radDateTimePicker1;
        private Telerik.WinControls.UI.RadDropDownList radDropDownList1;
        private Telerik.WinControls.UI.RadGridView invoiceLineRadGridView;
        private System.Windows.Forms.BindingSource invoiceLineBindingSource;
        private Telerik.WinControls.UI.RadGridView tankFillingRadGridView;
        private System.Windows.Forms.BindingSource tankFillingBindingSource;
        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.UI.RadGridView tankLevelStartViewRadGridView;
        private System.Windows.Forms.BindingSource tankLevelStartViewBindingSource;
        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer2;
        private Telerik.WinControls.UI.SplitPanel splitPanel4;
        private System.Windows.Forms.Panel panel3;
        private Telerik.WinControls.UI.SplitPanel splitPanel5;
        private Telerik.WinControls.UI.RadGridView radGridView1;
        private System.Windows.Forms.Panel panel2;
        private Telerik.WinControls.UI.RadCheckBox radCheckBox1;
        private Telerik.WinControls.UI.RadCheckBox radCheckBox2;
    }
}