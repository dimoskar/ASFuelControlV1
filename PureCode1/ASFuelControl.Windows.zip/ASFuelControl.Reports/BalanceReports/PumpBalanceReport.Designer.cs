namespace ASFuelControl.Reports.BalanceReports
{
    partial class PumpBalanceReport
    {
        #region Component Designer generated code
        /// <summary>
        /// Required method for telerik Reporting designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
            Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
            Telerik.Reporting.Group group3 = new Telerik.Reporting.Group();
            Telerik.Reporting.Group group4 = new Telerik.Reporting.Group();
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            Telerik.Reporting.Drawing.StyleRule styleRule2 = new Telerik.Reporting.Drawing.StyleRule();
            Telerik.Reporting.Drawing.StyleRule styleRule3 = new Telerik.Reporting.Drawing.StyleRule();
            Telerik.Reporting.Drawing.StyleRule styleRule4 = new Telerik.Reporting.Drawing.StyleRule();
            this.labelsGroupFooterSection = new Telerik.Reporting.GroupFooterSection();
            this.labelsGroupHeaderSection = new Telerik.Reporting.GroupHeaderSection();
            this.fuelTypeDataFuelTypeCodeGroupFooterSection = new Telerik.Reporting.GroupFooterSection();
            this.textBox3 = new Telerik.Reporting.TextBox();
            this.textBox4 = new Telerik.Reporting.TextBox();
            this.textBox5 = new Telerik.Reporting.TextBox();
            this.textBox6 = new Telerik.Reporting.TextBox();
            this.textBox9 = new Telerik.Reporting.TextBox();
            this.fuelTypeDataFuelTypeCodeGroupHeaderSection = new Telerik.Reporting.GroupHeaderSection();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.shape1 = new Telerik.Reporting.Shape();
            this.dispenserNumberGroupFooterSection = new Telerik.Reporting.GroupFooterSection();
            this.dispenserNumberGroupHeaderSection = new Telerik.Reporting.GroupHeaderSection();
            this.nozzleNumberGroupFooterSection = new Telerik.Reporting.GroupFooterSection();
            this.nozzleNumberGroupHeaderSection = new Telerik.Reporting.GroupHeaderSection();
            this.nozzleNumberDataTextBox = new Telerik.Reporting.TextBox();
            this.dispenserNumberDataTextBox = new Telerik.Reporting.TextBox();
            this.dispenserNumberCaptionTextBox = new Telerik.Reporting.TextBox();
            this.nozzleNumberCaptionTextBox = new Telerik.Reporting.TextBox();
            this.totalizerStartCaptionTextBox = new Telerik.Reporting.TextBox();
            this.totalizerEndCaptionTextBox = new Telerik.Reporting.TextBox();
            this.totalOutCaptionTextBox = new Telerik.Reporting.TextBox();
            this.totalOutNormalizedCaptionTextBox = new Telerik.Reporting.TextBox();
            this.totalSalesCaptionTextBox = new Telerik.Reporting.TextBox();
            this.totalLiterCheckCaptionTextBox = new Telerik.Reporting.TextBox();
            this.reportHeader = new Telerik.Reporting.ReportHeaderSection();
            this.titleTextBox = new Telerik.Reporting.TextBox();
            this.reportFooter = new Telerik.Reporting.ReportFooterSection();
            this.detail = new Telerik.Reporting.DetailSection();
            this.totalizerStartDataTextBox = new Telerik.Reporting.TextBox();
            this.totalizerEndDataTextBox = new Telerik.Reporting.TextBox();
            this.totalOutDataTextBox = new Telerik.Reporting.TextBox();
            this.totalOutNormalizedDataTextBox = new Telerik.Reporting.TextBox();
            this.totalSalesDataTextBox = new Telerik.Reporting.TextBox();
            this.totalLiterCheckDataTextBox = new Telerik.Reporting.TextBox();
            this.dispData = new Telerik.Reporting.ObjectDataSource();
            this.shape3 = new Telerik.Reporting.Shape();
            this.textBox1 = new Telerik.Reporting.TextBox();
            this.textBox7 = new Telerik.Reporting.TextBox();
            this.textBox8 = new Telerik.Reporting.TextBox();
            this.textBox10 = new Telerik.Reporting.TextBox();
            this.textBox11 = new Telerik.Reporting.TextBox();
            this.shape5 = new Telerik.Reporting.Shape();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // labelsGroupFooterSection
            // 
            this.labelsGroupFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.79446619749069214D);
            this.labelsGroupFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox1,
            this.textBox7,
            this.textBox8,
            this.textBox10,
            this.textBox11});
            this.labelsGroupFooterSection.Name = "labelsGroupFooterSection";
            this.labelsGroupFooterSection.Style.Visible = true;
            // 
            // labelsGroupHeaderSection
            // 
            this.labelsGroupHeaderSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.40583339333534241D);
            this.labelsGroupHeaderSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.shape1});
            this.labelsGroupHeaderSection.Name = "labelsGroupHeaderSection";
            this.labelsGroupHeaderSection.PrintOnEveryPage = true;
            this.labelsGroupHeaderSection.Style.Visible = false;
            // 
            // fuelTypeDataFuelTypeCodeGroupFooterSection
            // 
            this.fuelTypeDataFuelTypeCodeGroupFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.99980199337005615D);
            this.fuelTypeDataFuelTypeCodeGroupFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox3,
            this.textBox4,
            this.textBox5,
            this.textBox6,
            this.textBox9,
            this.shape3});
            this.fuelTypeDataFuelTypeCodeGroupFooterSection.Name = "fuelTypeDataFuelTypeCodeGroupFooterSection";
            this.fuelTypeDataFuelTypeCodeGroupFooterSection.Style.BackgroundColor = System.Drawing.Color.White;
            // 
            // textBox3
            // 
            this.textBox3.CanGrow = true;
            this.textBox3.Format = "{0:N2}";
            this.textBox3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.399999618530273D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.textBox3.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox3.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox3.Style.Font.Bold = true;
            this.textBox3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox3.StyleName = "Data";
            this.textBox3.Value = "=Sum(Fields.TotalLiterCheck)";
            // 
            // textBox4
            // 
            this.textBox4.CanGrow = true;
            this.textBox4.Format = "{0:N2}";
            this.textBox4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.1200008392334D), Telerik.Reporting.Drawing.Unit.Cm(0.01398977916687727D));
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.textBox4.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox4.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox4.Style.Font.Bold = true;
            this.textBox4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox4.StyleName = "Data";
            this.textBox4.Value = "=Sum(Fields.TotalSales)";
            // 
            // textBox5
            // 
            this.textBox5.CanGrow = true;
            this.textBox5.Format = "{0:N2}";
            this.textBox5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.840000152587891D), Telerik.Reporting.Drawing.Unit.Cm(0.01398977916687727D));
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.textBox5.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox5.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox5.Style.Font.Bold = true;
            this.textBox5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox5.StyleName = "Data";
            this.textBox5.Value = "=Sum(fields.TotalOutNormalized)";
            // 
            // textBox6
            // 
            this.textBox6.CanGrow = true;
            this.textBox6.Format = "{0:N2}";
            this.textBox6.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.559999465942383D), Telerik.Reporting.Drawing.Unit.Cm(0.01398977916687727D));
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.textBox6.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox6.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox6.Style.Font.Bold = true;
            this.textBox6.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox6.StyleName = "Data";
            this.textBox6.Value = "=Sum(fields.TotalOut)";
            // 
            // textBox9
            // 
            this.textBox9.CanGrow = true;
            this.textBox9.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.00010012308484874666D));
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.502500057220459D), Telerik.Reporting.Drawing.Unit.Cm(0.54781657457351685D));
            this.textBox9.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox9.Style.Color = System.Drawing.Color.Black;
            this.textBox9.Style.Font.Bold = true;
            this.textBox9.StyleName = "Caption";
            this.textBox9.Value = "������";
            // 
            // fuelTypeDataFuelTypeCodeGroupHeaderSection
            // 
            this.fuelTypeDataFuelTypeCodeGroupHeaderSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.79999995231628418D);
            this.fuelTypeDataFuelTypeCodeGroupHeaderSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox2});
            this.fuelTypeDataFuelTypeCodeGroupHeaderSection.Name = "fuelTypeDataFuelTypeCodeGroupHeaderSection";
            this.fuelTypeDataFuelTypeCodeGroupHeaderSection.Style.BackgroundColor = System.Drawing.Color.White;
            // 
            // textBox2
            // 
            this.textBox2.CanGrow = true;
            this.textBox2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.064249545335769653D), Telerik.Reporting.Drawing.Unit.Cm(9.9921220680698752E-05D));
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15.749917030334473D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.textBox2.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(14D);
            this.textBox2.StyleName = "Data";
            this.textBox2.Value = "= Fields.FuelTypeDescription";
            // 
            // shape1
            // 
            this.shape1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(0.10030011832714081D));
            this.shape1.Name = "shape1";
            this.shape1.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(26.646984100341797D), Telerik.Reporting.Drawing.Unit.Cm(0.30543333292007446D));
            this.shape1.Style.Color = System.Drawing.Color.Black;
            this.shape1.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(2D);
            // 
            // dispenserNumberGroupFooterSection
            // 
            this.dispenserNumberGroupFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.30000025033950806D);
            this.dispenserNumberGroupFooterSection.Name = "dispenserNumberGroupFooterSection";
            this.dispenserNumberGroupFooterSection.Style.Visible = false;
            // 
            // dispenserNumberGroupHeaderSection
            // 
            this.dispenserNumberGroupHeaderSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.40000021457672119D);
            this.dispenserNumberGroupHeaderSection.Name = "dispenserNumberGroupHeaderSection";
            this.dispenserNumberGroupHeaderSection.Style.Visible = false;
            // 
            // nozzleNumberGroupFooterSection
            // 
            this.nozzleNumberGroupFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.30583241581916809D);
            this.nozzleNumberGroupFooterSection.Name = "nozzleNumberGroupFooterSection";
            this.nozzleNumberGroupFooterSection.Style.Visible = false;
            // 
            // nozzleNumberGroupHeaderSection
            // 
            this.nozzleNumberGroupHeaderSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.79999959468841553D);
            this.nozzleNumberGroupHeaderSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.nozzleNumberCaptionTextBox,
            this.totalizerStartCaptionTextBox,
            this.totalizerEndCaptionTextBox,
            this.totalOutCaptionTextBox,
            this.totalOutNormalizedCaptionTextBox,
            this.totalSalesCaptionTextBox,
            this.totalLiterCheckCaptionTextBox,
            this.dispenserNumberCaptionTextBox});
            this.nozzleNumberGroupHeaderSection.Name = "nozzleNumberGroupHeaderSection";
            this.nozzleNumberGroupHeaderSection.Style.BackgroundColor = System.Drawing.Color.White;
            // 
            // nozzleNumberDataTextBox
            // 
            this.nozzleNumberDataTextBox.CanGrow = true;
            this.nozzleNumberDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.6967911720275879D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.nozzleNumberDataTextBox.Name = "nozzleNumberDataTextBox";
            this.nozzleNumberDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5470831394195557D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.nozzleNumberDataTextBox.Style.BackgroundColor = System.Drawing.Color.White;
            this.nozzleNumberDataTextBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.nozzleNumberDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.nozzleNumberDataTextBox.StyleName = "Data";
            this.nozzleNumberDataTextBox.Value = "=Fields.NozzleNumber";
            // 
            // dispenserNumberDataTextBox
            // 
            this.dispenserNumberDataTextBox.CanGrow = true;
            this.dispenserNumberDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.064249545335769653D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.dispenserNumberDataTextBox.Name = "dispenserNumberDataTextBox";
            this.dispenserNumberDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5470831394195557D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.dispenserNumberDataTextBox.Style.BackgroundColor = System.Drawing.Color.White;
            this.dispenserNumberDataTextBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.dispenserNumberDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.dispenserNumberDataTextBox.StyleName = "Data";
            this.dispenserNumberDataTextBox.Value = "=Fields.DispenserNumber";
            // 
            // dispenserNumberCaptionTextBox
            // 
            this.dispenserNumberCaptionTextBox.CanGrow = true;
            this.dispenserNumberCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.041584186255931854D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.dispenserNumberCaptionTextBox.Name = "dispenserNumberCaptionTextBox";
            this.dispenserNumberCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5584161281585693D), Telerik.Reporting.Drawing.Unit.Cm(0.59436613321304321D));
            this.dispenserNumberCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.dispenserNumberCaptionTextBox.StyleName = "Caption";
            this.dispenserNumberCaptionTextBox.Value = "������";
            // 
            // nozzleNumberCaptionTextBox
            // 
            this.nozzleNumberCaptionTextBox.CanGrow = true;
            this.nozzleNumberCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.6854586601257324D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.nozzleNumberCaptionTextBox.Name = "nozzleNumberCaptionTextBox";
            this.nozzleNumberCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5469579696655273D), Telerik.Reporting.Drawing.Unit.Cm(0.59436613321304321D));
            this.nozzleNumberCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.nozzleNumberCaptionTextBox.StyleName = "Caption";
            this.nozzleNumberCaptionTextBox.Value = "�����������";
            // 
            // totalizerStartCaptionTextBox
            // 
            this.totalizerStartCaptionTextBox.CanGrow = true;
            this.totalizerStartCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.9999995231628418D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalizerStartCaptionTextBox.Name = "totalizerStartCaptionTextBox";
            this.totalizerStartCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.59436613321304321D));
            this.totalizerStartCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.totalizerStartCaptionTextBox.StyleName = "Caption";
            this.totalizerStartCaptionTextBox.Value = "������ ��������";
            // 
            // totalizerEndCaptionTextBox
            // 
            this.totalizerEndCaptionTextBox.CanGrow = true;
            this.totalizerEndCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.279999732971191D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalizerEndCaptionTextBox.Name = "totalizerEndCaptionTextBox";
            this.totalizerEndCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.59436613321304321D));
            this.totalizerEndCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.totalizerEndCaptionTextBox.StyleName = "Caption";
            this.totalizerEndCaptionTextBox.Value = "���� ��������";
            // 
            // totalOutCaptionTextBox
            // 
            this.totalOutCaptionTextBox.CanGrow = true;
            this.totalOutCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.559999465942383D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalOutCaptionTextBox.Name = "totalOutCaptionTextBox";
            this.totalOutCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.59436613321304321D));
            this.totalOutCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.totalOutCaptionTextBox.StyleName = "Caption";
            this.totalOutCaptionTextBox.Value = "�������� �����";
            // 
            // totalOutNormalizedCaptionTextBox
            // 
            this.totalOutNormalizedCaptionTextBox.CanGrow = true;
            this.totalOutNormalizedCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.840000152587891D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalOutNormalizedCaptionTextBox.Name = "totalOutNormalizedCaptionTextBox";
            this.totalOutNormalizedCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.59436613321304321D));
            this.totalOutNormalizedCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.totalOutNormalizedCaptionTextBox.StyleName = "Caption";
            this.totalOutNormalizedCaptionTextBox.Value = "���. ����� 15�C";
            // 
            // totalSalesCaptionTextBox
            // 
            this.totalSalesCaptionTextBox.CanGrow = true;
            this.totalSalesCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.1200008392334D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalSalesCaptionTextBox.Name = "totalSalesCaptionTextBox";
            this.totalSalesCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.59436613321304321D));
            this.totalSalesCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.totalSalesCaptionTextBox.StyleName = "Caption";
            this.totalSalesCaptionTextBox.Value = "������ ��������";
            // 
            // totalLiterCheckCaptionTextBox
            // 
            this.totalLiterCheckCaptionTextBox.CanGrow = true;
            this.totalLiterCheckCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.399999618530273D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalLiterCheckCaptionTextBox.Name = "totalLiterCheckCaptionTextBox";
            this.totalLiterCheckCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.59436613321304321D));
            this.totalLiterCheckCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.totalLiterCheckCaptionTextBox.StyleName = "Caption";
            this.totalLiterCheckCaptionTextBox.Value = "������ �����/����";
            // 
            // reportHeader
            // 
            this.reportHeader.Height = Telerik.Reporting.Drawing.Unit.Cm(1.09416663646698D);
            this.reportHeader.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.titleTextBox});
            this.reportHeader.Name = "reportHeader";
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15.814167022705078D), Telerik.Reporting.Drawing.Unit.Cm(0.89416676759719849D));
            this.titleTextBox.StyleName = "Title";
            this.titleTextBox.Value = "�������� ������� ��� ���� ��������";
            // 
            // reportFooter
            // 
            this.reportFooter.Height = Telerik.Reporting.Drawing.Unit.Cm(0.49466779828071594D);
            this.reportFooter.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.shape5});
            this.reportFooter.Name = "reportFooter";
            this.reportFooter.Style.Visible = true;
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0.69989949464797974D);
            this.detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.totalizerStartDataTextBox,
            this.totalizerEndDataTextBox,
            this.totalOutDataTextBox,
            this.totalOutNormalizedDataTextBox,
            this.totalSalesDataTextBox,
            this.totalLiterCheckDataTextBox,
            this.dispenserNumberDataTextBox,
            this.nozzleNumberDataTextBox});
            this.detail.Name = "detail";
            // 
            // totalizerStartDataTextBox
            // 
            this.totalizerStartDataTextBox.CanGrow = true;
            this.totalizerStartDataTextBox.Format = "{0:N2}";
            this.totalizerStartDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.9999995231628418D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalizerStartDataTextBox.Name = "totalizerStartDataTextBox";
            this.totalizerStartDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.totalizerStartDataTextBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.totalizerStartDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.totalizerStartDataTextBox.StyleName = "Data";
            this.totalizerStartDataTextBox.Value = "=Fields.TotalizerStart";
            // 
            // totalizerEndDataTextBox
            // 
            this.totalizerEndDataTextBox.CanGrow = true;
            this.totalizerEndDataTextBox.Format = "{0:N2}";
            this.totalizerEndDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.279999732971191D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalizerEndDataTextBox.Name = "totalizerEndDataTextBox";
            this.totalizerEndDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.totalizerEndDataTextBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.totalizerEndDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.totalizerEndDataTextBox.StyleName = "Data";
            this.totalizerEndDataTextBox.Value = "=Fields.TotalizerEnd";
            // 
            // totalOutDataTextBox
            // 
            this.totalOutDataTextBox.CanGrow = true;
            this.totalOutDataTextBox.Format = "{0:N2}";
            this.totalOutDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.559999465942383D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalOutDataTextBox.Name = "totalOutDataTextBox";
            this.totalOutDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.totalOutDataTextBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.totalOutDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.totalOutDataTextBox.StyleName = "Data";
            this.totalOutDataTextBox.Value = "=Fields.TotalOut";
            // 
            // totalOutNormalizedDataTextBox
            // 
            this.totalOutNormalizedDataTextBox.CanGrow = true;
            this.totalOutNormalizedDataTextBox.Format = "{0:N2}";
            this.totalOutNormalizedDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.840000152587891D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalOutNormalizedDataTextBox.Name = "totalOutNormalizedDataTextBox";
            this.totalOutNormalizedDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.totalOutNormalizedDataTextBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.totalOutNormalizedDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.totalOutNormalizedDataTextBox.StyleName = "Data";
            this.totalOutNormalizedDataTextBox.Value = "=Fields.TotalOutNormalized";
            // 
            // totalSalesDataTextBox
            // 
            this.totalSalesDataTextBox.CanGrow = true;
            this.totalSalesDataTextBox.Format = "{0:N2}";
            this.totalSalesDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.1200008392334D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalSalesDataTextBox.Name = "totalSalesDataTextBox";
            this.totalSalesDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.totalSalesDataTextBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.totalSalesDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.totalSalesDataTextBox.StyleName = "Data";
            this.totalSalesDataTextBox.Value = "=Fields.TotalSales";
            // 
            // totalLiterCheckDataTextBox
            // 
            this.totalLiterCheckDataTextBox.CanGrow = true;
            this.totalLiterCheckDataTextBox.Format = "{0:N2}";
            this.totalLiterCheckDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.399999618530273D), Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D));
            this.totalLiterCheckDataTextBox.Name = "totalLiterCheckDataTextBox";
            this.totalLiterCheckDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.totalLiterCheckDataTextBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.totalLiterCheckDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.totalLiterCheckDataTextBox.StyleName = "Data";
            this.totalLiterCheckDataTextBox.Value = "=Fields.TotalLiterCheck";
            // 
            // dispData
            // 
            this.dispData.DataMember = "DispenserData";
            this.dispData.DataSource = "ASFuelControl.Reports.BalanceReports.BalanceDS, ASFuelControl.Reports, Version=1." +
    "0.0.0, Culture=neutral, PublicKeyToken=null";
            this.dispData.Name = "dispData";
            // 
            // shape3
            // 
            this.shape3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.026458332315087318D), Telerik.Reporting.Drawing.Unit.Cm(0.555138885974884D));
            this.shape3.Name = "shape3";
            this.shape3.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(26.646984100341797D), Telerik.Reporting.Drawing.Unit.Cm(0.30543333292007446D));
            this.shape3.Style.Color = System.Drawing.Color.Black;
            this.shape3.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(2D);
            // 
            // textBox1
            // 
            this.textBox1.CanGrow = true;
            this.textBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.0086251189932227135D), Telerik.Reporting.Drawing.Unit.Cm(0.094466127455234528D));
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.502500057220459D), Telerik.Reporting.Drawing.Unit.Cm(0.54781657457351685D));
            this.textBox1.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox1.Style.Color = System.Drawing.Color.Black;
            this.textBox1.Style.Font.Bold = true;
            this.textBox1.StyleName = "Caption";
            this.textBox1.Value = "���. ������";
            // 
            // textBox7
            // 
            this.textBox7.CanGrow = true;
            this.textBox7.Format = "{0:N2}";
            this.textBox7.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.559999465942383D), Telerik.Reporting.Drawing.Unit.Cm(0.094466127455234528D));
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.textBox7.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox7.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox7.Style.Font.Bold = true;
            this.textBox7.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox7.StyleName = "Data";
            this.textBox7.Value = "=Sum(fields.TotalOut)";
            // 
            // textBox8
            // 
            this.textBox8.CanGrow = true;
            this.textBox8.Format = "{0:N2}";
            this.textBox8.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.840000152587891D), Telerik.Reporting.Drawing.Unit.Cm(0.094466127455234528D));
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.textBox8.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox8.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox8.Style.Font.Bold = true;
            this.textBox8.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox8.StyleName = "Data";
            this.textBox8.Value = "=Sum(fields.TotalOutNormalized)";
            // 
            // textBox10
            // 
            this.textBox10.CanGrow = true;
            this.textBox10.Format = "{0:N2}";
            this.textBox10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.1200008392334D), Telerik.Reporting.Drawing.Unit.Cm(0.094466127455234528D));
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.textBox10.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox10.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox10.Style.Font.Bold = true;
            this.textBox10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox10.StyleName = "Data";
            this.textBox10.Value = "=Sum(Fields.TotalSales)";
            // 
            // textBox11
            // 
            this.textBox11.CanGrow = true;
            this.textBox11.Format = "{0:N2}";
            this.textBox11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.399999618530273D), Telerik.Reporting.Drawing.Unit.Cm(0.094466127455234528D));
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2000000476837158D), Telerik.Reporting.Drawing.Unit.Cm(0.540949285030365D));
            this.textBox11.Style.BackgroundColor = System.Drawing.Color.White;
            this.textBox11.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox11.Style.Font.Bold = true;
            this.textBox11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox11.StyleName = "Data";
            this.textBox11.Value = "=Sum(Fields.TotalLiterCheck)";
            // 
            // shape5
            // 
            this.shape5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.026458332315087318D), Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D));
            this.shape5.Name = "shape5";
            this.shape5.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(26.646984100341797D), Telerik.Reporting.Drawing.Unit.Cm(0.24175122380256653D));
            this.shape5.Style.Color = System.Drawing.Color.Black;
            this.shape5.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(4D);
            // 
            // PumpBalanceReport
            // 
            this.DataSource = this.dispData;
            group1.GroupFooter = this.labelsGroupFooterSection;
            group1.GroupHeader = this.labelsGroupHeaderSection;
            group1.Name = "labelsGroup";
            group2.GroupFooter = this.fuelTypeDataFuelTypeCodeGroupFooterSection;
            group2.GroupHeader = this.fuelTypeDataFuelTypeCodeGroupHeaderSection;
            group2.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.FuelTypeId"));
            group2.Name = "fuelTypeDataFuelTypeCodeGroup";
            group3.GroupFooter = this.dispenserNumberGroupFooterSection;
            group3.GroupHeader = this.dispenserNumberGroupHeaderSection;
            group3.Groupings.Add(new Telerik.Reporting.Grouping("=Fields.DispenserNumber"));
            group3.Name = "dispenserNumberGroup";
            group4.GroupFooter = this.nozzleNumberGroupFooterSection;
            group4.GroupHeader = this.nozzleNumberGroupHeaderSection;
            group4.Groupings.Add(new Telerik.Reporting.Grouping("=Fields.NozzleNumber"));
            group4.Name = "nozzleNumberGroup";
            this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2,
            group3,
            group4});
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.labelsGroupHeaderSection,
            this.labelsGroupFooterSection,
            this.fuelTypeDataFuelTypeCodeGroupHeaderSection,
            this.fuelTypeDataFuelTypeCodeGroupFooterSection,
            this.dispenserNumberGroupHeaderSection,
            this.dispenserNumberGroupFooterSection,
            this.nozzleNumberGroupHeaderSection,
            this.nozzleNumberGroupFooterSection,
            this.reportHeader,
            this.reportFooter,
            this.detail});
            this.Name = "PumpBalanceReport";
            this.PageSettings.Landscape = true;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Mm(15D), Telerik.Reporting.Drawing.Unit.Mm(15D), Telerik.Reporting.Drawing.Unit.Mm(15D), Telerik.Reporting.Drawing.Unit.Mm(15D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            this.Style.BackgroundColor = System.Drawing.Color.White;
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.StyleSelector("Title")});
            styleRule1.Style.Color = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(58)))), ((int)(((byte)(112)))));
            styleRule1.Style.Font.Name = "Tahoma";
            styleRule1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(18D);
            styleRule2.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.StyleSelector("Caption")});
            styleRule2.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(58)))), ((int)(((byte)(112)))));
            styleRule2.Style.Color = System.Drawing.Color.White;
            styleRule2.Style.Font.Name = "Tahoma";
            styleRule2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            styleRule2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            styleRule3.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.StyleSelector("Data")});
            styleRule3.Style.Color = System.Drawing.Color.Black;
            styleRule3.Style.Font.Name = "Tahoma";
            styleRule3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            styleRule3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            styleRule4.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.StyleSelector("PageInfo")});
            styleRule4.Style.Color = System.Drawing.Color.Black;
            styleRule4.Style.Font.Name = "Tahoma";
            styleRule4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            styleRule4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1,
            styleRule2,
            styleRule3,
            styleRule4});
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(26.700002670288086D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
        #endregion

        private Telerik.Reporting.GroupHeaderSection labelsGroupHeaderSection;
        private Telerik.Reporting.TextBox dispenserNumberCaptionTextBox;
        private Telerik.Reporting.TextBox nozzleNumberCaptionTextBox;
        private Telerik.Reporting.TextBox totalizerStartCaptionTextBox;
        private Telerik.Reporting.TextBox totalizerEndCaptionTextBox;
        private Telerik.Reporting.TextBox totalOutCaptionTextBox;
        private Telerik.Reporting.TextBox totalOutNormalizedCaptionTextBox;
        private Telerik.Reporting.TextBox totalSalesCaptionTextBox;
        private Telerik.Reporting.TextBox totalLiterCheckCaptionTextBox;
        private Telerik.Reporting.GroupFooterSection labelsGroupFooterSection;
        private Telerik.Reporting.GroupHeaderSection fuelTypeDataFuelTypeCodeGroupHeaderSection;
        private Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.GroupFooterSection fuelTypeDataFuelTypeCodeGroupFooterSection;
        private Telerik.Reporting.TextBox textBox3;
        private Telerik.Reporting.TextBox textBox4;
        private Telerik.Reporting.TextBox textBox5;
        private Telerik.Reporting.TextBox textBox6;
        private Telerik.Reporting.GroupHeaderSection dispenserNumberGroupHeaderSection;
        private Telerik.Reporting.GroupFooterSection dispenserNumberGroupFooterSection;
        private Telerik.Reporting.GroupHeaderSection nozzleNumberGroupHeaderSection;
        private Telerik.Reporting.TextBox nozzleNumberDataTextBox;
        private Telerik.Reporting.TextBox dispenserNumberDataTextBox;
        private Telerik.Reporting.GroupFooterSection nozzleNumberGroupFooterSection;
        private Telerik.Reporting.ReportHeaderSection reportHeader;
        private Telerik.Reporting.TextBox titleTextBox;
        private Telerik.Reporting.ReportFooterSection reportFooter;
        private Telerik.Reporting.DetailSection detail;
        private Telerik.Reporting.TextBox totalizerStartDataTextBox;
        private Telerik.Reporting.TextBox totalizerEndDataTextBox;
        private Telerik.Reporting.TextBox totalOutDataTextBox;
        private Telerik.Reporting.TextBox totalOutNormalizedDataTextBox;
        private Telerik.Reporting.TextBox totalSalesDataTextBox;
        private Telerik.Reporting.TextBox totalLiterCheckDataTextBox;
        private Telerik.Reporting.TextBox textBox9;
        private Telerik.Reporting.ObjectDataSource dispData;
        private Telerik.Reporting.Shape shape1;
        private Telerik.Reporting.Shape shape3;
        private Telerik.Reporting.TextBox textBox1;
        private Telerik.Reporting.TextBox textBox7;
        private Telerik.Reporting.TextBox textBox8;
        private Telerik.Reporting.TextBox textBox10;
        private Telerik.Reporting.TextBox textBox11;
        private Telerik.Reporting.Shape shape5;

    }
}