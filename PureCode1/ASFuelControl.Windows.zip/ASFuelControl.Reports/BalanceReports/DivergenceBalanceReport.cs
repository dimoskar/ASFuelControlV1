namespace ASFuelControl.Reports.BalanceReports
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using Telerik.Reporting;
    using Telerik.Reporting.Drawing;

    /// <summary>
    /// Summary description for DivergenceBalanceReport.
    /// </summary>
    public partial class DivergenceBalanceReport : Telerik.Reporting.Report
    {
        public DivergenceBalanceReport()
        {
            //
            // Required for telerik Reporting designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }
    }
}