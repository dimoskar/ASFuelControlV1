namespace ASFuelControl.Reports
{
    partial class InvoiceThermal
    {
        #region Component Designer generated code
        /// <summary>
        /// Required method for telerik Reporting designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
            Telerik.Reporting.Drawing.FormattingRule formattingRule2 = new Telerik.Reporting.Drawing.FormattingRule();
            Telerik.Reporting.Drawing.FormattingRule formattingRule3 = new Telerik.Reporting.Drawing.FormattingRule();
            Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            Telerik.Reporting.Drawing.StyleRule styleRule2 = new Telerik.Reporting.Drawing.StyleRule();
            Telerik.Reporting.Drawing.StyleRule styleRule3 = new Telerik.Reporting.Drawing.StyleRule();
            Telerik.Reporting.Drawing.StyleRule styleRule4 = new Telerik.Reporting.Drawing.StyleRule();
            this.labelsGroupFooterSection = new Telerik.Reporting.GroupFooterSection();
            this.textBox4 = new Telerik.Reporting.TextBox();
            this.labelsGroupHeaderSection = new Telerik.Reporting.GroupHeaderSection();
            this.nameCaptionTextBox = new Telerik.Reporting.TextBox();
            this.unitPriceCaptionTextBox = new Telerik.Reporting.TextBox();
            this.volumeCaptionTextBox = new Telerik.Reporting.TextBox();
            this.totalAmountCaptionTextBox = new Telerik.Reporting.TextBox();
            this.shape5 = new Telerik.Reporting.Shape();
            this.InvoiceThermalDS = new Telerik.Reporting.ObjectDataSource();
            this.pageHeader = new Telerik.Reporting.PageHeaderSection();
            this.companyOccupationDataTextBox = new Telerik.Reporting.TextBox();
            this.companyNameDataTextBox = new Telerik.Reporting.TextBox();
            this.companyAddressDataTextBox = new Telerik.Reporting.TextBox();
            this.companyCityDataTextBox = new Telerik.Reporting.TextBox();
            this.companyTINDataTextBox = new Telerik.Reporting.TextBox();
            this.companyTaxOfficeDataTextBox = new Telerik.Reporting.TextBox();
            this.companyPhoneDataTextBox = new Telerik.Reporting.TextBox();
            this.companyFaxDataTextBox = new Telerik.Reporting.TextBox();
            this.traderNameDataTextBox = new Telerik.Reporting.TextBox();
            this.vehicleNumberDataTextBox = new Telerik.Reporting.TextBox();
            this.descriptionDataTextBox = new Telerik.Reporting.TextBox();
            this.numberDataTextBox = new Telerik.Reporting.TextBox();
            this.transactionDateDataTextBox = new Telerik.Reporting.TextBox();
            this.shape1 = new Telerik.Reporting.Shape();
            this.shape2 = new Telerik.Reporting.Shape();
            this.textBox1 = new Telerik.Reporting.TextBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.textBox3 = new Telerik.Reporting.TextBox();
            this.shape3 = new Telerik.Reporting.Shape();
            this.shape4 = new Telerik.Reporting.Shape();
            this.pageFooter = new Telerik.Reporting.PageFooterSection();
            this.barcode1 = new Telerik.Reporting.Barcode();
            this.textBox5 = new Telerik.Reporting.TextBox();
            this.textBox6 = new Telerik.Reporting.TextBox();
            this.textBox7 = new Telerik.Reporting.TextBox();
            this.textBox8 = new Telerik.Reporting.TextBox();
            this.textBox9 = new Telerik.Reporting.TextBox();
            this.textBox10 = new Telerik.Reporting.TextBox();
            this.textBox11 = new Telerik.Reporting.TextBox();
            this.reportHeader = new Telerik.Reporting.ReportHeaderSection();
            this.detail = new Telerik.Reporting.DetailSection();
            this.nameDataTextBox = new Telerik.Reporting.TextBox();
            this.volumeDataTextBox = new Telerik.Reporting.TextBox();
            this.totalAmountDataTextBox = new Telerik.Reporting.TextBox();
            this.unitPriceDataTextBox = new Telerik.Reporting.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // labelsGroupFooterSection
            // 
            this.labelsGroupFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.71437495946884155D);
            this.labelsGroupFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox4});
            this.labelsGroupFooterSection.Name = "labelsGroupFooterSection";
            this.labelsGroupFooterSection.Style.Visible = true;
            // 
            // textBox4
            // 
            this.textBox4.CanGrow = true;
            this.textBox4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.066758684813976288D), Telerik.Reporting.Drawing.Unit.Cm(0.11447378993034363D));
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.8873958587646484D), Telerik.Reporting.Drawing.Unit.Cm(0.59980064630508423D));
            this.textBox4.StyleName = "Data";
            this.textBox4.Value = "������:{Fields.OfficialPumpNumber} �����������:{Fields.OfficialNozzleNumber}";
            // 
            // labelsGroupHeaderSection
            // 
            this.labelsGroupHeaderSection.Height = Telerik.Reporting.Drawing.Unit.Cm(0.79396826028823853D);
            this.labelsGroupHeaderSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.nameCaptionTextBox,
            this.unitPriceCaptionTextBox,
            this.volumeCaptionTextBox,
            this.totalAmountCaptionTextBox,
            this.shape5});
            this.labelsGroupHeaderSection.Name = "labelsGroupHeaderSection";
            this.labelsGroupHeaderSection.PrintOnEveryPage = true;
            // 
            // nameCaptionTextBox
            // 
            this.nameCaptionTextBox.CanGrow = true;
            this.nameCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D));
            this.nameCaptionTextBox.Name = "nameCaptionTextBox";
            this.nameCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5999999046325684D), Telerik.Reporting.Drawing.Unit.Cm(0.54708421230316162D));
            this.nameCaptionTextBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.nameCaptionTextBox.StyleName = "Caption";
            this.nameCaptionTextBox.Value = "�����";
            // 
            // unitPriceCaptionTextBox
            // 
            this.unitPriceCaptionTextBox.CanGrow = true;
            this.unitPriceCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.6000001430511475D), Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D));
            this.unitPriceCaptionTextBox.Name = "unitPriceCaptionTextBox";
            this.unitPriceCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.2997995615005493D), Telerik.Reporting.Drawing.Unit.Cm(0.54708504676818848D));
            this.unitPriceCaptionTextBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.unitPriceCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.unitPriceCaptionTextBox.StyleName = "Caption";
            this.unitPriceCaptionTextBox.Value = "���� ���";
            // 
            // volumeCaptionTextBox
            // 
            this.volumeCaptionTextBox.CanGrow = true;
            this.volumeCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.8999998569488525D), Telerik.Reporting.Drawing.Unit.Cm(0.0529150515794754D));
            this.volumeCaptionTextBox.Name = "volumeCaptionTextBox";
            this.volumeCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3804235458374023D), Telerik.Reporting.Drawing.Unit.Cm(0.54708504676818848D));
            this.volumeCaptionTextBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.volumeCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.volumeCaptionTextBox.StyleName = "Caption";
            this.volumeCaptionTextBox.Value = "�����";
            // 
            // totalAmountCaptionTextBox
            // 
            this.totalAmountCaptionTextBox.CanGrow = true;
            this.totalAmountCaptionTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(5.2999997138977051D), Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D));
            this.totalAmountCaptionTextBox.Name = "totalAmountCaptionTextBox";
            this.totalAmountCaptionTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.7000013589859009D), Telerik.Reporting.Drawing.Unit.Cm(0.54708504676818848D));
            this.totalAmountCaptionTextBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.totalAmountCaptionTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.totalAmountCaptionTextBox.StyleName = "Caption";
            this.totalAmountCaptionTextBox.Value = "������";
            // 
            // shape5
            // 
            this.shape5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.60020238161087036D));
            this.shape5.Name = "shape5";
            this.shape5.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.0000009536743164D), Telerik.Reporting.Drawing.Unit.Cm(0.13229165971279144D));
            this.shape5.Style.LineStyle = Telerik.Reporting.Drawing.LineStyle.Dashed;
            // 
            // InvoiceThermalDS
            // 
            this.InvoiceThermalDS.DataSource = "ASFuelControl.Data.InvoicePrintView, ASFuelControl.Data, Version=1.0.0.0, Culture" +
    "=neutral, PublicKeyToken=null";
            this.InvoiceThermalDS.Name = "InvoiceThermalDS";
            // 
            // pageHeader
            // 
            this.pageHeader.Height = Telerik.Reporting.Drawing.Unit.Cm(8D);
            this.pageHeader.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.companyOccupationDataTextBox,
            this.companyNameDataTextBox,
            this.companyAddressDataTextBox,
            this.companyCityDataTextBox,
            this.companyTINDataTextBox,
            this.companyTaxOfficeDataTextBox,
            this.companyPhoneDataTextBox,
            this.companyFaxDataTextBox,
            this.traderNameDataTextBox,
            this.vehicleNumberDataTextBox,
            this.descriptionDataTextBox,
            this.numberDataTextBox,
            this.transactionDateDataTextBox,
            this.shape1,
            this.shape2,
            this.textBox1,
            this.textBox2,
            this.textBox3,
            this.shape3,
            this.shape4});
            this.pageHeader.Name = "pageHeader";
            // 
            // companyOccupationDataTextBox
            // 
            this.companyOccupationDataTextBox.CanGrow = true;
            this.companyOccupationDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(9.9921220680698752E-05D));
            this.companyOccupationDataTextBox.Name = "companyOccupationDataTextBox";
            this.companyOccupationDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.9470844268798828D), Telerik.Reporting.Drawing.Unit.Cm(0.5998002290725708D));
            this.companyOccupationDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.companyOccupationDataTextBox.StyleName = "Data";
            this.companyOccupationDataTextBox.TextWrap = false;
            this.companyOccupationDataTextBox.Value = "=Fields.CompanyOccupation";
            // 
            // companyNameDataTextBox
            // 
            this.companyNameDataTextBox.CanGrow = true;
            this.companyNameDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(0.600100040435791D));
            this.companyNameDataTextBox.Name = "companyNameDataTextBox";
            this.companyNameDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.9470834732055664D), Telerik.Reporting.Drawing.Unit.Cm(0.59406661987304688D));
            this.companyNameDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.companyNameDataTextBox.StyleName = "Data";
            this.companyNameDataTextBox.Value = "=Fields.CompanyName";
            // 
            // companyAddressDataTextBox
            // 
            this.companyAddressDataTextBox.CanGrow = true;
            this.companyAddressDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(1.1943668127059937D));
            this.companyAddressDataTextBox.Name = "companyAddressDataTextBox";
            this.companyAddressDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.9469828605651855D), Telerik.Reporting.Drawing.Unit.Cm(0.49979948997497559D));
            this.companyAddressDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.companyAddressDataTextBox.StyleName = "Data";
            this.companyAddressDataTextBox.Value = "=Fields.CompanyAddress";
            // 
            // companyCityDataTextBox
            // 
            this.companyCityDataTextBox.CanGrow = true;
            this.companyCityDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(1.6943665742874146D));
            this.companyCityDataTextBox.Name = "companyCityDataTextBox";
            this.companyCityDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.8873958587646484D), Telerik.Reporting.Drawing.Unit.Cm(0.499799907207489D));
            this.companyCityDataTextBox.StyleName = "Data";
            this.companyCityDataTextBox.Value = "=Fields.CompanyCity";
            // 
            // companyTINDataTextBox
            // 
            this.companyTINDataTextBox.CanGrow = true;
            this.companyTINDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(2.1943666934967041D));
            this.companyTINDataTextBox.Name = "companyTINDataTextBox";
            this.companyTINDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9470834732055664D), Telerik.Reporting.Drawing.Unit.Cm(0.499799907207489D));
            this.companyTINDataTextBox.StyleName = "Data";
            this.companyTINDataTextBox.Value = "�.�.�.:{Fields.CompanyTIN}";
            // 
            // companyTaxOfficeDataTextBox
            // 
            this.companyTaxOfficeDataTextBox.CanGrow = true;
            this.companyTaxOfficeDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.0002002716064453D), Telerik.Reporting.Drawing.Unit.Cm(2.1943666934967041D));
            this.companyTaxOfficeDataTextBox.Name = "companyTaxOfficeDataTextBox";
            this.companyTaxOfficeDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.9998006820678711D), Telerik.Reporting.Drawing.Unit.Cm(0.499799907207489D));
            this.companyTaxOfficeDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.companyTaxOfficeDataTextBox.StyleName = "Data";
            this.companyTaxOfficeDataTextBox.Value = "�.�.�.:{Fields.CompanyTaxOffice}";
            // 
            // companyPhoneDataTextBox
            // 
            this.companyPhoneDataTextBox.CanGrow = true;
            this.companyPhoneDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(2.6943669319152832D));
            this.companyPhoneDataTextBox.Name = "companyPhoneDataTextBox";
            this.companyPhoneDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.8873958587646484D), Telerik.Reporting.Drawing.Unit.Cm(0.59979981184005737D));
            this.companyPhoneDataTextBox.StyleName = "Data";
            this.companyPhoneDataTextBox.Value = "�������� : {Fields.CompanyPhone}";
            // 
            // companyFaxDataTextBox
            // 
            this.companyFaxDataTextBox.CanGrow = true;
            this.companyFaxDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.9932291507720947D), Telerik.Reporting.Drawing.Unit.Cm(2.6943669319152832D));
            this.companyFaxDataTextBox.Name = "companyFaxDataTextBox";
            this.companyFaxDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.0067718029022217D), Telerik.Reporting.Drawing.Unit.Cm(0.59979987144470215D));
            this.companyFaxDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.companyFaxDataTextBox.StyleName = "Data";
            this.companyFaxDataTextBox.Value = "Fax : {Fields.CompanyFax}";
            // 
            // traderNameDataTextBox
            // 
            this.traderNameDataTextBox.CanGrow = true;
            this.traderNameDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.3999996185302734D));
            this.traderNameDataTextBox.Name = "traderNameDataTextBox";
            this.traderNameDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.9998998641967773D), Telerik.Reporting.Drawing.Unit.Cm(0.4999997615814209D));
            this.traderNameDataTextBox.StyleName = "Data";
            this.traderNameDataTextBox.Value = "= Fields.TraderDescription";
            // 
            // vehicleNumberDataTextBox
            // 
            this.vehicleNumberDataTextBox.CanGrow = true;
            formattingRule1.Filters.Add(new Telerik.Reporting.Filter("=Fields.HasTrader", Telerik.Reporting.FilterOperator.Equal, "= False"));
            formattingRule1.Style.Visible = false;
            this.vehicleNumberDataTextBox.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
            this.vehicleNumberDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(5.9001998901367188D));
            this.vehicleNumberDataTextBox.Name = "vehicleNumberDataTextBox";
            this.vehicleNumberDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.8873958587646484D), Telerik.Reporting.Drawing.Unit.Cm(0.59980064630508423D));
            this.vehicleNumberDataTextBox.StyleName = "Data";
            this.vehicleNumberDataTextBox.Value = "=Fields.VehicleNumber";
            // 
            // descriptionDataTextBox
            // 
            this.descriptionDataTextBox.CanGrow = true;
            this.descriptionDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(3.8000001907348633D));
            this.descriptionDataTextBox.Name = "descriptionDataTextBox";
            this.descriptionDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.53991174697876D), Telerik.Reporting.Drawing.Unit.Cm(0.59980148077011108D));
            this.descriptionDataTextBox.StyleName = "Data";
            this.descriptionDataTextBox.TextWrap = false;
            this.descriptionDataTextBox.Value = "=Fields.Description";
            // 
            // numberDataTextBox
            // 
            this.numberDataTextBox.CanGrow = true;
            this.numberDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.7998991012573242D), Telerik.Reporting.Drawing.Unit.Cm(3.8000001907348633D));
            this.numberDataTextBox.Name = "numberDataTextBox";
            this.numberDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.200000524520874D), Telerik.Reporting.Drawing.Unit.Cm(0.59980148077011108D));
            this.numberDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.numberDataTextBox.StyleName = "Data";
            this.numberDataTextBox.Value = "=Fields.Number";
            // 
            // transactionDateDataTextBox
            // 
            this.transactionDateDataTextBox.CanGrow = true;
            this.transactionDateDataTextBox.Format = "{0:dd/MM/yyyy HH:mm:ss}";
            this.transactionDateDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(4.4000020027160645D));
            this.transactionDateDataTextBox.Name = "transactionDateDataTextBox";
            this.transactionDateDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.539912223815918D), Telerik.Reporting.Drawing.Unit.Cm(0.500000536441803D));
            this.transactionDateDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.transactionDateDataTextBox.StyleName = "Data";
            this.transactionDateDataTextBox.Value = "����������: {Fields.TransactionDate.ToString(\"dd/MM/yyyy\")}";
            // 
            // shape1
            // 
            this.shape1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.0999999046325684D));
            this.shape1.Name = "shape1";
            this.shape1.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.0000014305114746D), Telerik.Reporting.Drawing.Unit.Cm(0.13229165971279144D));
            this.shape1.Style.LineStyle = Telerik.Reporting.Drawing.LineStyle.Dashed;
            // 
            // shape2
            // 
            this.shape2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.00010012308484874666D), Telerik.Reporting.Drawing.Unit.Cm(6.5999999046325684D));
            this.shape2.Name = "shape2";
            this.shape2.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.999901294708252D), Telerik.Reporting.Drawing.Unit.Cm(0.13229165971279144D));
            this.shape2.Style.LineStyle = Telerik.Reporting.Drawing.LineStyle.Dashed;
            // 
            // textBox1
            // 
            this.textBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.59999942779541D), Telerik.Reporting.Drawing.Unit.Cm(4.4000020027160645D));
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4000022411346436D), Telerik.Reporting.Drawing.Unit.Cm(0.500000536441803D));
            this.textBox1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            this.textBox1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox1.Value = "���: {Fields.TransactionDate.ToString(\"HH:mm:ss\")}";
            // 
            // textBox2
            // 
            this.textBox2.CanGrow = true;
            this.textBox2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.052916664630174637D), Telerik.Reporting.Drawing.Unit.Cm(6.9000000953674316D));
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.8873958587646484D), Telerik.Reporting.Drawing.Unit.Cm(0.59980064630508423D));
            this.textBox2.StyleName = "Data";
            this.textBox2.Value = "���� ������";
            // 
            // textBox3
            // 
            this.textBox3.CanGrow = true;
            this.textBox3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.8000006675720215D), Telerik.Reporting.Drawing.Unit.Cm(6.900001049041748D));
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.200000524520874D), Telerik.Reporting.Drawing.Unit.Cm(0.59980064630508423D));
            this.textBox3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox3.StyleName = "Data";
            this.textBox3.Value = "���������";
            // 
            // shape3
            // 
            this.shape3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(7.6999998092651367D));
            this.shape3.Name = "shape3";
            this.shape3.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.0000014305114746D), Telerik.Reporting.Drawing.Unit.Cm(0.13229165971279144D));
            this.shape3.Style.LineStyle = Telerik.Reporting.Drawing.LineStyle.Dashed;
            // 
            // shape4
            // 
            this.shape4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(7.5D));
            this.shape4.Name = "shape4";
            this.shape4.ShapeType = new Telerik.Reporting.Drawing.Shapes.LineShape(Telerik.Reporting.Drawing.Shapes.LineDirection.EW);
            this.shape4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.0000014305114746D), Telerik.Reporting.Drawing.Unit.Cm(0.13229165971279144D));
            this.shape4.Style.LineStyle = Telerik.Reporting.Drawing.LineStyle.Dashed;
            // 
            // pageFooter
            // 
            this.pageFooter.Height = Telerik.Reporting.Drawing.Unit.Cm(6.2856254577636719D);
            this.pageFooter.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.barcode1,
            this.textBox5,
            this.textBox6,
            this.textBox7,
            this.textBox8,
            this.textBox9,
            this.textBox10,
            this.textBox11});
            this.pageFooter.Name = "pageFooter";
            // 
            // barcode1
            // 
            formattingRule2.Filters.Add(new Telerik.Reporting.Filter("= Parameters.PrintBarcode.Value", Telerik.Reporting.FilterOperator.Equal, "= False"));
            formattingRule2.Style.Visible = false;
            this.barcode1.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule2});
            this.barcode1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.099999949336051941D), Telerik.Reporting.Drawing.Unit.Cm(2.8856263160705566D));
            this.barcode1.Name = "barcode1";
            this.barcode1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.7998991012573242D), Telerik.Reporting.Drawing.Unit.Cm(1.9000002145767212D));
            this.barcode1.Style.Color = System.Drawing.Color.Black;
            this.barcode1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.barcode1.Symbology = Telerik.Reporting.Barcode.SymbologyType.Code25Interleaved;
            this.barcode1.Value = "= ASFuelControl.Reports.InvoiceReportFunctions.GetBarcode(Fields.InvoiceLineId)";
            // 
            // textBox5
            // 
            this.textBox5.CanGrow = true;
            this.textBox5.Format = "{0:N2}";
            this.textBox5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.733241081237793D), Telerik.Reporting.Drawing.Unit.Cm(0.28562614321708679D));
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2666583061218262D), Telerik.Reporting.Drawing.Unit.Cm(0.54708182811737061D));
            this.textBox5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox5.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.10000000149011612D);
            this.textBox5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox5.StyleName = "Data";
            this.textBox5.Value = "=Sum(Fields.Volume)";
            // 
            // textBox6
            // 
            this.textBox6.CanGrow = true;
            this.textBox6.Format = "{0:N2}";
            this.textBox6.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.733241081237793D), Telerik.Reporting.Drawing.Unit.Cm(0.83290863037109375D));
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2666583061218262D), Telerik.Reporting.Drawing.Unit.Cm(0.54708182811737061D));
            this.textBox6.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox6.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.10000000149011612D);
            this.textBox6.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox6.StyleName = "Data";
            this.textBox6.Value = "=Sum(Fields.TotalAmount)";
            // 
            // textBox7
            // 
            this.textBox7.CanGrow = true;
            formattingRule3.Filters.Add(new Telerik.Reporting.Filter("=Fields.VatAmount", Telerik.Reporting.FilterOperator.Equal, "=0"));
            formattingRule3.Style.Visible = false;
            this.textBox7.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule3});
            this.textBox7.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.5801901817321777D));
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.9999995231628418D), Telerik.Reporting.Drawing.Unit.Cm(0.59980064630508423D));
            this.textBox7.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox7.StyleName = "Data";
            this.textBox7.Value = "=\"�� ����� ������������� �.�.�.\"";
            // 
            // textBox8
            // 
            this.textBox8.CanGrow = true;
            this.textBox8.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.1801905632019043D));
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.9999995231628418D), Telerik.Reporting.Drawing.Unit.Cm(0.59980064630508423D));
            this.textBox8.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox8.StyleName = "Data";
            this.textBox8.Value = "=\"������������ ��� ��� ���������� ���\"";
            // 
            // textBox9
            // 
            this.textBox9.CanGrow = true;
            this.textBox9.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.7332420349121094D), Telerik.Reporting.Drawing.Unit.Cm(0.28562450408935547D));
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9470834732055664D), Telerik.Reporting.Drawing.Unit.Cm(0.54708421230316162D));
            this.textBox9.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox9.StyleName = "Caption";
            this.textBox9.Value = "������ ��������� :";
            // 
            // textBox10
            // 
            this.textBox10.CanGrow = true;
            this.textBox10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.7332425117492676D), Telerik.Reporting.Drawing.Unit.Cm(0.83290696144104D));
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9470834732055664D), Telerik.Reporting.Drawing.Unit.Cm(0.54708421230316162D));
            this.textBox10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox10.StyleName = "Caption";
            this.textBox10.Value = "������ ��������� : ";
            // 
            // textBox11
            // 
            this.textBox11.CanGrow = true;
            this.textBox11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.88562536239624D));
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.9999995231628418D), Telerik.Reporting.Drawing.Unit.Cm(1.2000010013580322D));
            this.textBox11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox11.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.textBox11.StyleName = "Data";
            this.textBox11.Value = "����� ��������: {Fields.InvoiceSignature}";
            // 
            // reportHeader
            // 
            this.reportHeader.Height = Telerik.Reporting.Drawing.Unit.Cm(0.80603188276290894D);
            this.reportHeader.Name = "reportHeader";
            this.reportHeader.Style.Visible = false;
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0.69999879598617554D);
            this.detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.nameDataTextBox,
            this.volumeDataTextBox,
            this.totalAmountDataTextBox,
            this.unitPriceDataTextBox});
            this.detail.Name = "detail";
            // 
            // nameDataTextBox
            // 
            this.nameDataTextBox.CanGrow = true;
            this.nameDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.00010012308484874666D));
            this.nameDataTextBox.Name = "nameDataTextBox";
            this.nameDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5999999046325684D), Telerik.Reporting.Drawing.Unit.Cm(0.54708182811737061D));
            this.nameDataTextBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.nameDataTextBox.StyleName = "Data";
            this.nameDataTextBox.Value = "=Fields.Name";
            // 
            // volumeDataTextBox
            // 
            this.volumeDataTextBox.CanGrow = true;
            this.volumeDataTextBox.Format = "{0:N2}";
            this.volumeDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.8999998569488525D), Telerik.Reporting.Drawing.Unit.Cm(0.00010012308484874666D));
            this.volumeDataTextBox.Name = "volumeDataTextBox";
            this.volumeDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3804235458374023D), Telerik.Reporting.Drawing.Unit.Cm(0.54708182811737061D));
            this.volumeDataTextBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.volumeDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.volumeDataTextBox.StyleName = "Data";
            this.volumeDataTextBox.Value = "=Fields.Volume";
            // 
            // totalAmountDataTextBox
            // 
            this.totalAmountDataTextBox.CanGrow = true;
            this.totalAmountDataTextBox.Format = "{0:N2}";
            this.totalAmountDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(5.2999997138977051D), Telerik.Reporting.Drawing.Unit.Cm(0.00010012308484874666D));
            this.totalAmountDataTextBox.Name = "totalAmountDataTextBox";
            this.totalAmountDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.7000013589859009D), Telerik.Reporting.Drawing.Unit.Cm(0.54708182811737061D));
            this.totalAmountDataTextBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.totalAmountDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.totalAmountDataTextBox.StyleName = "Data";
            this.totalAmountDataTextBox.Value = "=Fields.TotalAmount";
            // 
            // unitPriceDataTextBox
            // 
            this.unitPriceDataTextBox.CanGrow = true;
            this.unitPriceDataTextBox.Format = "{0:N3}";
            this.unitPriceDataTextBox.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.6000001430511475D), Telerik.Reporting.Drawing.Unit.Cm(0.00010012308484874666D));
            this.unitPriceDataTextBox.Name = "unitPriceDataTextBox";
            this.unitPriceDataTextBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.2997995615005493D), Telerik.Reporting.Drawing.Unit.Cm(0.54708182811737061D));
            this.unitPriceDataTextBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.unitPriceDataTextBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.unitPriceDataTextBox.StyleName = "Data";
            this.unitPriceDataTextBox.Value = "=Fields.UnitPrice";
            // 
            // InvoiceThermal
            // 
            this.DataSource = this.InvoiceThermalDS;
            this.Filters.Add(new Telerik.Reporting.Filter("=Fields.InvoiceId.ToString()", Telerik.Reporting.FilterOperator.Equal, "=Parameters.InvoiceId.Value"));
            group1.GroupFooter = this.labelsGroupFooterSection;
            group1.GroupHeader = this.labelsGroupHeaderSection;
            group1.Name = "labelsGroup";
            this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.labelsGroupHeaderSection,
            this.labelsGroupFooterSection,
            this.pageHeader,
            this.pageFooter,
            this.reportHeader,
            this.detail});
            this.Name = "InvoiceThermal";
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Mm(0D), Telerik.Reporting.Drawing.Unit.Mm(5D), Telerik.Reporting.Drawing.Unit.Mm(2D), Telerik.Reporting.Drawing.Unit.Mm(2D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Custom;
            this.PageSettings.PaperSize = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Mm(80D), Telerik.Reporting.Drawing.Unit.Mm(190D));
            reportParameter1.Name = "InvoiceId";
            reportParameter1.Value = "755DE982-D689-4713-AB9B-00C6E5D4A6F7";
            reportParameter2.Name = "PrintBarcode";
            reportParameter2.Type = Telerik.Reporting.ReportParameterType.Boolean;
            this.ReportParameters.Add(reportParameter1);
            this.ReportParameters.Add(reportParameter2);
            this.Style.BackgroundColor = System.Drawing.Color.White;
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.StyleSelector("Title")});
            styleRule1.Style.Color = System.Drawing.Color.Black;
            styleRule1.Style.Font.Bold = true;
            styleRule1.Style.Font.Italic = false;
            styleRule1.Style.Font.Name = "Tahoma";
            styleRule1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(18D);
            styleRule1.Style.Font.Strikeout = false;
            styleRule1.Style.Font.Underline = false;
            styleRule2.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.StyleSelector("Caption")});
            styleRule2.Style.Color = System.Drawing.Color.Black;
            styleRule2.Style.Font.Name = "Tahoma";
            styleRule2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            styleRule2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            styleRule3.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.StyleSelector("Data")});
            styleRule3.Style.Font.Name = "Tahoma";
            styleRule3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
            styleRule3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            styleRule4.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.StyleSelector("PageInfo")});
            styleRule4.Style.Font.Name = "Tahoma";
            styleRule4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            styleRule4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1,
            styleRule2,
            styleRule3,
            styleRule4});
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(7.0000014305114746D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
        #endregion

        private Telerik.Reporting.ObjectDataSource InvoiceThermalDS;
        private Telerik.Reporting.GroupHeaderSection labelsGroupHeaderSection;
        private Telerik.Reporting.TextBox nameCaptionTextBox;
        private Telerik.Reporting.TextBox unitPriceCaptionTextBox;
        private Telerik.Reporting.TextBox volumeCaptionTextBox;
        private Telerik.Reporting.TextBox totalAmountCaptionTextBox;
        private Telerik.Reporting.GroupFooterSection labelsGroupFooterSection;
        private Telerik.Reporting.PageHeaderSection pageHeader;
        private Telerik.Reporting.PageFooterSection pageFooter;
        private Telerik.Reporting.ReportHeaderSection reportHeader;
        private Telerik.Reporting.TextBox companyOccupationDataTextBox;
        private Telerik.Reporting.TextBox companyNameDataTextBox;
        private Telerik.Reporting.TextBox companyAddressDataTextBox;
        private Telerik.Reporting.TextBox companyCityDataTextBox;
        private Telerik.Reporting.TextBox companyTINDataTextBox;
        private Telerik.Reporting.TextBox companyTaxOfficeDataTextBox;
        private Telerik.Reporting.TextBox companyPhoneDataTextBox;
        private Telerik.Reporting.TextBox companyFaxDataTextBox;
        private Telerik.Reporting.TextBox traderNameDataTextBox;
        private Telerik.Reporting.TextBox vehicleNumberDataTextBox;
        private Telerik.Reporting.TextBox descriptionDataTextBox;
        private Telerik.Reporting.TextBox numberDataTextBox;
        private Telerik.Reporting.TextBox transactionDateDataTextBox;
        private Telerik.Reporting.DetailSection detail;
        private Telerik.Reporting.TextBox nameDataTextBox;
        private Telerik.Reporting.TextBox unitPriceDataTextBox;
        private Telerik.Reporting.TextBox volumeDataTextBox;
        private Telerik.Reporting.TextBox totalAmountDataTextBox;
        private Telerik.Reporting.Barcode barcode1;
        private Telerik.Reporting.Shape shape1;
        private Telerik.Reporting.Shape shape2;
        private Telerik.Reporting.TextBox textBox1;
        private Telerik.Reporting.TextBox textBox4;
        private Telerik.Reporting.Shape shape5;
        private Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.TextBox textBox3;
        private Telerik.Reporting.Shape shape3;
        private Telerik.Reporting.Shape shape4;
        private Telerik.Reporting.TextBox textBox5;
        private Telerik.Reporting.TextBox textBox6;
        private Telerik.Reporting.TextBox textBox7;
        private Telerik.Reporting.TextBox textBox8;
        private Telerik.Reporting.TextBox textBox9;
        private Telerik.Reporting.TextBox textBox10;
        private Telerik.Reporting.TextBox textBox11;

    }
}