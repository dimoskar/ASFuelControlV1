﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASFuelControl.Common.Enumerators
{
    public enum ControllerTypeEnum
    {
        Box69,
        Elbis,
        PTS,
        AK6,
        Millenium,
        NuovoPignone,
        Teosis,
        Ametek,
        StartItaliana,
        Fafnir,
        Gilbarco,
        None
    }
}
