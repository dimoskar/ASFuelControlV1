﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASFuelControl.VirtualDevices
{
    public class VirtualTank : VirtualDevice
    {
        #region Private Variables

        private Common.TankValues tankValues;
        private Common.Enumerators.TankStatusEnum tankStatus = Common.Enumerators.TankStatusEnum.Offline;
        private decimal currentFuelLevel = 0;
        private decimal currentWaterLevel = 0;
        private decimal currentTemperature = 0;
        private bool initializeFilling = false;
        private bool fillingFinished = false;
        private bool initializeExtraction = false;
        private bool extractionFinished = false;

        #endregion

        #region public properties

        public Guid InvoiceLineId { set; get; }

        public Guid InvoiceTypeId { set; get; }
        public Guid VehicleId { set; get; }
        public Guid FillingFuelTypeId { set; get; }

        public VirtualTitrimetryLevel[] TitrimetryLevels { set; get; }
        public VirtualNozzle[] ConnectedNozzles { set; get; }
        public int TankNumber { set; get; }
        public Guid TankId { set; get; }
        public int ChannelId { set; get; }
        public int AddressId { set; get; }
        public decimal ThermalCoefficient { set; get; }
        public decimal BaseDensity { set; get; }
        public decimal OrderLimit { set; get; }
        public int BaseColor { set; get; }
        public int DeliveryTime { set; get; }
        public int LiterCheckTime { set; get; }
        public DateTime WaitingStarted { set; get; }
        public DateTime WaitingShouldEnd { set; get; }
        public bool IsLiterCheck { set; get; }
        public bool IsVirtualTank { set; get; }

        public bool InitializeFilling 
        {
            set 
            {
                if (value == this.initializeFilling)
                    return;
                this.initializeFilling = value;
                this.OnPropertyChanged(this, "InitializeFilling");
            }
            get { return this.initializeFilling; }
        }

        public bool InitializeExtraction
        {
            set
            {
                if (value == this.initializeExtraction)
                    return;
                this.initializeExtraction = value;
                this.OnPropertyChanged(this, "InitializeExtraction");
            }
            get { return this.initializeExtraction; }
        }

        public bool FillingFinished
        {
            set
            {
                if (value == this.fillingFinished)
                    return;
                this.fillingFinished = value;
                this.OnPropertyChanged(this, "FillingFinished");
            }
            get { return this.fillingFinished; }
        }

        public bool ExtractionFinished
        {
            set
            {
                if (value == this.extractionFinished)
                    return;
                this.extractionFinished = value;
                this.OnPropertyChanged(this, "ExtractionFinished");
            }
            get { return this.extractionFinished; }
        }

        public Common.Enumerators.TankStatusEnum TankStatus
        {
            set
            {
                if (this.tankStatus == value)
                    return;
                this.PreviousStatus = this.tankStatus;
                this.tankStatus = value;
                this.OnPropertyChanged(this, "TankStatus");
            }
            get { return this.tankStatus; }
        }
        public Common.Enumerators.TankStatusEnum PreviousStatus
        {
            set;
            get;
        }

        public decimal CurrentTemperature
        {
            set
            {
                if (this.currentTemperature == value)
                    return;
                this.currentTemperature = value;
                this.OnPropertyChanged(this, "CurrentTemperature");
                this.OnPropertyChanged(this, "CurrentVolumeNormalized");
            }
            get { return this.currentTemperature; }
        }
        public decimal CurrentFuelLevel
        {
            set
            {
                if (this.currentFuelLevel == value)
                    return;
                this.currentFuelLevel = value;
                //this.CurrentVolumeNormalized = this.NormalizeVolume(this.GetTankVolume(this.currentFuelLevel), this.currentTemperature, this.CurrentDensity);
                this.OnPropertyChanged(this, "CurrentFuelLevel");
                this.OnPropertyChanged(this, "CurrentVolume");
                this.OnPropertyChanged(this, "CurrentVolumeNormalized");
                this.OnPropertyChanged(this, "CurrentFuelPercentage");
                this.OnPropertyChanged(this, "OrderPending");
            }
            get { return this.currentFuelLevel; }
        }
        public decimal CurrentWaterLevel
        {
            set
            {
                if (this.currentWaterLevel == value)
                    return;
                this.currentWaterLevel = value;
                this.OnPropertyChanged(this, "CurrentWaterLevel");
                this.OnPropertyChanged(this, "CurrentWaterVolume");
                this.OnPropertyChanged(this, "CurrentWaterPercentage");
            }
            get { return this.currentWaterLevel; }
        }

        public decimal FuelOffset { set; get; }
        public decimal WaterOffset { set; get; }

        public decimal CurrentDensity { set; get; }
        public decimal CurrentVolume
        {
            get
            {
                return this.GetTankVolume(this.CurrentFuelLevel);
            }
        }
        public decimal CurrentVolumeNormalized
        {
            get
            {
                return this.NormalizeVolume(this.CurrentVolume, this.currentTemperature, this.CurrentDensity);
            }
        }

        public decimal LastTemperature { set; get; }
        public decimal LastFuelHeight { set; get; }
        public decimal LastWaterHeight { set; get; }

        public decimal TotalVolume { set; get; }
        public decimal MaxHeight { set; get; }
        public decimal MinHeight { set; get; }
        public decimal MaxWaterHeight { set; get; }
        public decimal MinWaterHeight { set; get; }
        public decimal PriceAverage { set; get; }

        public Common.TankValues TankValues
        {
            set
            {
                this.tankValues = value;
                if (this.tankStatus == null)
                    return;
                this.OnPropertyChanged(this, "TankValues");
                //if (this.TankStatus != Common.Enumerators.TankStatusEnum.Selling)
                //    return;
                //foreach (VirtualNozzle nozzle in this.ConnectedNozzles)
                //{
                //    if (nozzle.ParentDispenser.DispenserStatus == Common.Enumerators.FuelPointStatusEnum.Idle || nozzle.ParentDispenser.DispenserStatus == Common.Enumerators.FuelPointStatusEnum.SalingCompleted)
                //    {
                //        nozzle.ParentDispenser.TankValuesUpdated = true;
                //        nozzle.ParentDispenser.WorkFlow.Process.EvaluateWorkFlow();
                //    }
                //}
            }
            get { return this.tankValues; }
        }

        public bool OrderPending
        {
            get
            {
                if (this.OrderLimit > this.CurrentVolume && !this.IsVirtualTank)
                    return true;
                return false;
            }
        }

        public string FuelTypeDescription { set; get; }
        public string FuelTypeShort { set; get; }
        public Guid FuelTypeId { set; get; }

        #endregion

        #region public Methods

        public VirtualTank()
        {
            this.ConnectedNozzles = new VirtualNozzle[] { };
        }

        public decimal GetTankVolume(decimal height)
        {
            if (this.TitrimetryLevels == null)
                return 0;
            if (height <= 0)
                return 0;
            VirtualTitrimetryLevel previousLevel = this.TitrimetryLevels.OrderBy(tml => tml.Height).Where(tml => tml.Height <= height).LastOrDefault();
            VirtualTitrimetryLevel nextLevel = this.TitrimetryLevels.OrderBy(tml => tml.Height).Where(tml => tml.Height > height).FirstOrDefault();
            if (nextLevel != null)
            {
                decimal volDiff = nextLevel.Volume - (previousLevel == null ? 0 : previousLevel.Volume);
                decimal heightStep = nextLevel.Height - (previousLevel == null ? 0 : previousLevel.Height);
                decimal dHeight = height - (previousLevel == null ? 0 : previousLevel.Height);
                decimal dVolume = volDiff * dHeight / heightStep;
                return (previousLevel == null ? 0 : previousLevel.Volume) + dVolume;
            }
            else
            {
                return (previousLevel == null ? 0 : previousLevel.Volume);
            }
        }

        public decimal NormalizeVolume(decimal volStart, decimal temp, decimal density)
        {
            if (this.ThermalCoefficient == 0 || this.BaseDensity == 0)
                return volStart;

            decimal dt = 15 - temp;
            decimal coefficient = density * (this.ThermalCoefficient / this.BaseDensity);
            decimal dv = volStart * coefficient * dt;
            return volStart + dv;
        }

        public decimal CalculateStatisticalErrors(decimal level)
        {
            try
            {
                decimal error = 0;
                VirtualTitrimetryLevel l1 = this.TitrimetryLevels.OrderBy(t => t.Height).Where(t => t.Height <= level).LastOrDefault();
                VirtualTitrimetryLevel l2 = this.TitrimetryLevels.OrderBy(t => t.Height).Where(t => t.Height >= level).FirstOrDefault();
                if (l1 == null || l2 == null)
                    return 0;

                if (l2.Equals(l1))
                    l2 = this.TitrimetryLevels.OrderBy(t => t.Height).Where(t => t.Height >= level).Skip(1).FirstOrDefault();

                error = 3 * (l2.Height - l1.Height);
                error = 3 * (l2.Volume - l1.Volume);
                return error;
            }
            catch
            {
                return 0;
            }
        }

        #endregion
    }
}
